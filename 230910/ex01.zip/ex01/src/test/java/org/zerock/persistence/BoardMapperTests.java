package org.zerock.persistence;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.BoardVO;
import org.zerock.domain.Criteria;
import org.zerock.mapper.BoardMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BoardMapperTests {
	
	@Setter(onMethod_ = @Autowired )
	private BoardMapper boardMapper;
	
	@Test	
	public void replyCntTest() {
		
		
		log.info(boardMapper.updateReplyCnt(1, 8));
	}
	
	
	public void searchTest() {
		Criteria cri = new Criteria();
		
		cri.setType("W");          // 1. 작성자에서 검색 작성자는 W!!
		cri.setKeyword("ㅁㅁㅁ");
		
		boardMapper.selectAllPaging(cri).forEach(bvo -> log.info(bvo));
		
		log.info("total count : " + boardMapper.totalCount(cri));
		
		cri.setType("TC");		  // 2. 제목 또는 내용에서 검색
		cri.setKeyword("new");
		boardMapper.selectAllPaging(cri).forEach(bvo -> log.info(bvo));
		
		log.info("total count : " + boardMapper.totalCount(cri));
		
	}
	
	

	public void selectPagingTest() {	
		Criteria cri = new Criteria();
		
		log.info("---------------------------");
		boardMapper.selectAllPaging(cri).forEach(bvo -> log.info(bvo));
		log.info("---------------------------");
		
		cri = new Criteria(3,2);
		
		boardMapper.selectAllPaging(cri).forEach(bvo -> log.info(bvo));
		log.info("---------------------------");
		
		log.info("total count : " + boardMapper.totalCount(cri));
	}
			
	
	
	public void update() {							 // update
		
		 BoardVO bvo = new BoardVO();					// BoardVO 객체 생성
		 
		 bvo.setBno(4);
		 bvo.setTitle("hello");
		 bvo.setContent("hi");
		 bvo.setWriter("yoohoo");
		
		 log.info("update count : " +boardMapper.update(bvo));  // 로 확인 가능 이렇게하면 업데이는 되는 개수
		 														// mapper에서 int로 return맞춰놓음
		
	}
		
	
	public void delete() {							// delete
		
		boardMapper.delete(1); 
		// log.info("delete count : " + boardMapper.delete(1)); 로 확인 가능
		
	}
	
		

	public void insertSelectKey() {						// insert
		
		 BoardVO bvo = new BoardVO();					// BoardVO 객체 생성
		 
		 bvo.setTitle("newnew title");					// 원래는 값 입력받는걸로 자동
		 bvo.setContent("newnew content");				// 여기서는 test 해보려고
		 bvo.setWriter("newnew writer");
		 
		 boardMapper.insert(bvo);						// boardMapper에 inset에 bvo 담아서 호출
		 
		 log.info(bvo);									// log에 찍어보기
		
	}
	
	
	public void testInsert() {						// insert
		
		 BoardVO bvo = new BoardVO();				// BoardVO 객체 생성
		 
		 bvo.setTitle("new title");					// 원래는 값 입력받는걸로 자동
		 bvo.setContent("new content");				// 여기서는 test 해보려고
		 bvo.setWriter("new writer");
		 
		 boardMapper.insert(bvo);					// boardMapper에 inset에 bvo 담아서 호출
		 
		 log.info(bvo);								// log에 찍어보기
		
	}
	

	public void testSelect() {
		log.info("---------------------------");
		 boardMapper.select(5);									// 하나 가져오는건 매개변수 사용
		log.info("---------------------------");
		
	}
				
	
	public void testSelecAll() {
		log.info("---------------------------");
		boardMapper.selectAll().forEach(bvo -> log.info(bvo));			// 람다식 사용해서 람다식 사용하는거
		log.info("---------------------------");
		
	}
	
	
	
	
	
}
