package org.zerock.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.ProductVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ProductServiceTests {
	
	@Setter(onMethod_ = @Autowired)
	private ProductService productService;
	
	
	
	public void listTest() {   // 성공
		log.info("---------------------");
		productService.list().forEach(pvo -> log.info(pvo));	
		log.info("---------------------");
		
		
	}
	
	
	public void viewTest() {			// 성공
		log.info(productService.view("P1234"));
		
	}
	
	
	public void registerTest() {   // 성공
		
		ProductVO pvo = new ProductVO();
		
		pvo.setPid("P1239");
		pvo.setPname("호식이");
		pvo.setPrice(3000);
		pvo.setDescription("매운간장");
		pvo.setMaker("빨리");
		pvo.setCategory("먹고");
		pvo.setStock(100);
		pvo.setCondition("싶다");
		pvo.setPimage("chicken.png");
		
		productService.register(pvo);
		
		log.info("등록 성공" + pvo);
		 
	}
	
	
	
	public void modifyTest() {			// 성공
		ProductVO pvo = new ProductVO();
		
		pvo.setPid("P1238");
		pvo.setPname("초코파이 vs 오예스");
		pvo.setPrice(3000);
		pvo.setDescription("오예스 얼려먹기");
		pvo.setMaker("오리온");
		pvo.setCategory("빵?");
		pvo.setStock(100);
		pvo.setCondition("new");
		pvo.setPimage("choco.png");
		
		
		if(productService.modify(pvo)) {
			log.info("수정 성공");
		};
		
	}
	
	@Test
	public void removeTest() {	  // 성공
		
		log.info("delete count :" + productService.remove("P1234"));
		
	}
	

}
