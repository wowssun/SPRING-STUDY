package org.zerock.persistence;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.BoardAttachVO;
import org.zerock.domain.ProductImgVO;
import org.zerock.mapper.ProductImgMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ProductImgMapperTests {

	
		@Setter(onMethod_ = @Autowired )
		private ProductImgMapper productImgMapper;
		
		public void delete() {							// delete
			
			productImgMapper.delete("uuid"); 
			// uuid는 String
				
			}
		
		public void testInsert() {						// insert
			
			 ProductImgVO pivo = new ProductImgVO();				// BoardVO 객체 생성
			  
			 // 여기 확인해보기
			 pivo.setPid("bbb");
			 pivo.setFileName("파일");
			 pivo.setImage(true);
			 pivo.setUpFolder("폴더");
			 pivo.setUuid("uuid");
			 
			 productImgMapper.insert(pivo);					// boardMapper에 inset에 bvo 담아서 호출
			 
			 log.info(pivo);								// log에 찍어보기
			
		}
		
		@Test
		public void testSelecAll() {
			log.info("---------------------------");
			productImgMapper.selectAll("bbb").forEach(pivo -> log.info(pivo));			// 람다식 사용해서 람다식 사용하는거
			log.info("---------------------------");
			
		}
		
	
		public void deletAll() {   // 
			
		
			log.info(productImgMapper.deleteAll("bbb"));
		}
		
		
		
}
