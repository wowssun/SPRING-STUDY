CREATE TABLE product_img (
pid varchar2(10) CONSTRAINT fk_product_attach REFERENCES product(pid),
uuid VARChaR2(100) CONSTRAINT pk_img PRIMARY KEY,
upFolder Varchar2(200) not null,
fileName varchar2(100) not null,
image char(1));

insert into product_img values ( 'P1238','UUID','2023\09\08','P1234.png',1); 

delete from product_img where pid = 'P1238';
select * from product_img;


CREATE TABLE tbl_attach (
    bno NUMBER CONSTRAINT fk_board_attach REFERENCES tb1_board(bno),
    uuid VARChaR2(100) CONSTRAINT pk_attach PRIMARY KEY,
    upFolder Varchar2(200) not null,
    fileName varchar2(100) not null,
    image char(1));

select * from tbl_attach;

SELECT * FROM tbl_attach WHERE bno =13;

CREATE TABLE tbl_reply (
    rno     NUMBER  CONSTRAINT pk_reply PRIMARY KEY,
    bno     NUMBER  CONSTRAINT fk_reply REFERENCES tb1_board(bno) NOT NULL,
    reply   VARCHAR2(1000) NOT NULL,
    replyer VARCHAR2(50)   NOT NULL,
    regDate     DATE    DEFAULT SYSDATE,
    updateDate  DATE    DEFAULT SYSDATE
);

CREATE INDEX idx_reply ON tbl_reply(bno DESC, rno ASC);

 /*+INDEX_DESC(tbl_reply bno) */

 /*+INDEX_DESC(tb1_board pk_board) */

 CREATE INDEX idx_board ON tb1_board(bno DESC);
 
 
CREATE SEQUENCE seq_reply NOCACHE;

CREATE TABLE tb1_board (
    bno number constraint pk_board primary key,
    title varchar2(200) not null,
    content varchar2(200) not null,
    writer varchar2(200) not null,
    regdate date default sysdate,
    updatedate date default sysdate );
    


ALTER TABLE tb1_board ADD replyCnt number;

UPDATE tb1_board SET replyCnt =(SELECT count(*) FROM tbl_reply where tbl_reply.bno=tb1_board.bno); 

UPDATE tb1_board SET replyCnt = replyCnt + 1 WHERE  bno = 8;

 
SELECT count(*) FROM tbl_reply where bno=50;

 
create sequence seq_board nocache;
 
 insert into tb1_board(bno,title, content, writer)
 values(seq_board.nextval, '테스트 제목', '테스트 내용', 'user00');
 
 select * from tb1_board;
 select * from tbl_reply;
 
 SELECT * FROM tb1_board ORDER BY bno DESC;


 SELECT  bno, title, content, writer, regDate, updateDate
    FROM ( SELECT /*+INDEX_DESC(tb1_board pk_board) */
    			rownum rn, bno, title, content, writer,
    			regDate, updateDate
    			FROM tb1_board
    			WHERE rownum <= 3 * 2)
  	WHERE rn > 3 * (2-1);
    
SELECT rno, bno, reply, replyer, regDate, updateDate
     FROM (SELECT /*+INDEX(tbl_reply idx_reply) */
        rownum rn,bno, rno, reply, replyer, regDate, updateDate
        FROM tbl_reply
        WHERE bno = 13 
        AND rownum <= 3 * 1)
        WHERE rn > 3 * (1-1);
 
SELECT COUNT(*) FROM tbl_reply WHERE bno=50;
 
CREATE TABLE tbl_sample1(coll varchar2(100));
CREATE TABLE tbl_sample2(coll varchar2(10));
 
INSERT INTO tbl_sample1 VALUES('하이루');

insert into tbl_attach values(88,'uuid','2023\08\31','파일이름',0);
insert into tbl_attach values(8, 'uiui','2023\08\31','파일네임',1);

select * from tbl_sample1;
select * from tbl_Sample2;


select * from tbl_attach
WHERE TO_DATE(upFolder, 'yyyy\MM\dd') >= TRUNC(SYSDATE) - 1
AND TO_DATE(upFolder, 'yyyy-MM-dd') < TRUNC(SYSDATE); 

select * from tbl_attach
WHERE upFolder= TO_CHAR(SYSDATE - 1, 'yyyy\MM\dd');

SELECT * from tbl_attach
		WHERE upFolder= TO_CHAR(SYSDATE - 1, 'yyyy\MM\dd'); 	

select * from tbl_attach;

insert into tbl_attach values(8, 'uiui','2023\08\31','파일네임.png',1);

DELETE FROM tbl_attach WHERE BNO=8;

CREATE TABLE tbl_review (
    revno     NUMBER  CONSTRAINT pk_review PRIMARY KEY,
    pid     varchar2(10)  CONSTRAINT fk_review REFERENCES product(pid) NOT NULL,
    review   VARCHAR2(1000) NOT NULL,
    reviewer VARCHAR2(50)   NOT NULL,
    regDate     DATE    DEFAULT SYSDATE,
    updateDate  DATE    DEFAULT SYSDATE
);

CREATE SEQUENCE seq_review NOCACHE;

ALTER TABLE product ADD reviewCnt number;

insert into tbl_review(revno, pid, review, reviewer)
values(seq_review.nextval,'P1234', '리뷰 내용', 'user00');

select * from tb1_board;
select * from product;
select * from tbl_review;

create table tbl_member (
    id varchar2(50) primary key,
    pw varchar2(100) not null,
    name varchar2(100) not null,
    regDate date default sysdate,
    updateDate date default sysdate,
    enabled char(1) default '1');
    
 CREATE TABLE tbl_member_auth(
    id VARCHAR2(50) NOT NULL CONSTRAINT fk_member_auth REFERENCES tbl_member(id),
    auth VARCHAR2(50) NOT NULL);   


CREATE TABLE users (
    username VARCHAR2(50) PRIMARY KEY,
    password VARCHAR2(50) NOT NULL,
    enabled CHAR(1) DEFAULT '1' );
  
-- 권한  
CREATE TABLE authorities(
    username VARCHAR2(50) NOT NULL CONSTRAINT fk_authorities_users REFERENCES users(username),
    authority VARCHAR2(50) NOT NULL);
    
CREATE UNIQUE INDEX ix_auth_username
ON authorities(username, authority);
 
INSERT INTO users(username, password) VALUES('user00','1111'); 
INSERT INTO users(username, password) VALUES('member00','1111'); 
INSERT INTO users(username, password) VALUES('admin00','1111'); 

INSERT INTO authorities VALUES('user00', 'ROLE_USER');
INSERT INTO authorities VALUES('member00', 'ROLE_MEMBER');
INSERT INTO authorities VALUES('admin00', 'ROLE_MEMBER');
INSERT INTO authorities VALUES('admin00', 'ROLE_ADMIN');
    
    
COMMIT; 

select * from users;
select * from authorities;

 commit;
 