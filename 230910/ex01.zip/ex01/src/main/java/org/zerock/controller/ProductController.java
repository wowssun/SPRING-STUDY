package org.zerock.controller;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.zerock.domain.BoardAttachVO;
import org.zerock.domain.Criteria;
import org.zerock.domain.PageDTO;
import org.zerock.domain.ProductImgVO;
import org.zerock.domain.ProductVO;
import org.zerock.service.ProductService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/product/*")
@AllArgsConstructor
public class ProductController {
	
	private ProductService productService;
	
	// 첨부 파일 삭제  
		public void deleteImg(List<ProductImgVO>imgList) {
		log.info("delete img.....");
			
			if(imgList == null || imgList.size() == 0) {
				return;
			}
			
			imgList.forEach(pivo -> {
				Path file = Paths.get("c:\\upload\\product\\" + pivo.getUpFolder() + "\\" +
																pivo.getUuid() + "_" +
																pivo.getFileName());
				try {
					Files.deleteIfExists(file);
					
					if(Files.probeContentType(file).startsWith("image")) {
						Path thumbnail = Paths.get("c:\\upload\\product\\" + 
													pivo.getUpFolder() + "\\s_" +
													pivo.getUuid() + "_" +
													pivo.getFileName());
						Files.deleteIfExists(thumbnail);
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			});
			
		}
	
	
	

	// 상품 전체 목록 + 페이징
	@GetMapping("list")
	public void list(Model model, Criteria cri) {
			
	log.info("pro controller list....." + cri);
	
	model.addAttribute("list", productService.list(cri));
	
	
	model.addAttribute("pageDTO", new PageDTO(cri,productService.totalCount(cri)));
	}
	
	
	// 상품 조회
	@GetMapping({"view" , "modify"})
	public void view(String pid, Model model,@ModelAttribute("cri") Criteria cri) {
		log.info(" pro controller view or modify...");
		
		model.addAttribute("pvo", productService.view(pid));
	}		
	
	// 상품 등록 ( 화면 )
	@GetMapping("register")
	@PreAuthorize("isAuthenticated()")
	public void register() {
		
		log.info("pro controller register.....");
	}
	
	// 상품 등록( 폼 submit)
	@PostMapping("register")
	@PreAuthorize("isAuthenticated()")
	public String register(ProductVO pvo, RedirectAttributes rttr) {
		log.info("pro controller registerrrrrrr.....");
	
		if(productService.register(pvo)) {
			
			rttr.addFlashAttribute("result", pvo.getPid());
			
		}				
		return "redirect:/product/list";
	}
	
	// 상품 수정
	@PostMapping("modify")
	public String modify(ProductVO pvo, RedirectAttributes rttr,@ModelAttribute("cri") Criteria cri) {
		log.info("pro controller modify.....");
		
		productService.modify(pvo);
		
		rttr.addFlashAttribute("result", "modify success");
		
		rttr.addAttribute("pageNum", cri.getPageNum());
		rttr.addAttribute("amount", cri.getAmount());
		
		
		return "redirect:/product/list" ;
	}
	
	
	// 상품 삭제
	@PostMapping("remove")
	public String remove(String pid, RedirectAttributes rttr, @ModelAttribute("cri") Criteria cri) {
		log.info("pro controller remove....");
		
		
		List<ProductImgVO>imgList = productService.imgList(pid);
		
		if(productService.remove(pid)) {
			
			// 이미지 파일 삭제
			deleteImg(imgList);
			
			// 성공시
			rttr.addFlashAttribute("result","remove success");
		}			
		
		rttr.addAttribute("pageNum", cri.getPageNum());
		rttr.addAttribute("amount", cri.getAmount());
		
		return "redirect:/product/list" ;
	}
	
	@GetMapping(value = "imgList")
	public ResponseEntity <List<ProductImgVO>> imgList (String pid){
	 log.info("imgList : " + pid);
	return new ResponseEntity<>(productService.imgList(pid), HttpStatus.OK);
	}
	
	
}
