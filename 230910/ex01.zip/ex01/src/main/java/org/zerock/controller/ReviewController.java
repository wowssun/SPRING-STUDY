package org.zerock.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.zerock.domain.Criteria;

import org.zerock.domain.ReviewPageDTO;
import org.zerock.domain.ReviewVO;
import org.zerock.service.ReviewService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@RestController    // json 받을 수 있도록 restController로 변경해야한다.
@Log4j
@RequestMapping("/reviews/")
@AllArgsConstructor
public class ReviewController {
	
	private ReviewService reviewService;
	
	@GetMapping(value = "pages/{pid}/{pageNum}")
	public ResponseEntity <ReviewPageDTO> list(@PathVariable("pid") String pid,@PathVariable int pageNum) {
				
		log.info("review list......");
		
		Criteria cri = new Criteria(3,pageNum);   // cri 값을 지정한 경우, pageNum은 일단 파라미터로 받음.
													// 실제로 돌릴때는 변경해서
		
		// 댓글 목록 및 200번 상태 코드 반환
		return new ResponseEntity <ReviewPageDTO>(
				reviewService.list(pid, cri),HttpStatus.OK);
	}



	
	//JSON 데이터를 받아서 VO 객체로 반환
	@PostMapping(value = "add",
				 produces = {MediaType.TEXT_PLAIN_VALUE})
	@PreAuthorize("isAuthenticated()")
	public ResponseEntity<String> add(@RequestBody ReviewVO revvo) {   // 스프링에서 돌려보내기 할때는 이걸쓴다.
		log.info(" review add....");									// 확인용		
		
		
		// 파라미터로 값 보내야 함.
		// 댓글 등록 성공이면 200과 success 반환, 실패하면 500 코드(INTERNAL_SERVER_ERROR 반환

		return reviewService.add(revvo) 
				? new ResponseEntity<String>("success", HttpStatus.OK)
			    : new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
		
		// jsp 파일로 보내면 안되고 mapping 된 list로 보내야 한다. 리턴하고 다시 가는 곳이 같으면  void 사용
		// 그렇지 않을때는 String 으로 
	}
	
	
	// 하나 조회하기
	// rno만 받으니까 @PathVariable로 받는다. url 경로를 사용해서 rno를 받으니까
	@GetMapping(value = "{revno}")
	public ResponseEntity<ReviewVO> view(@PathVariable int revno) {		
																			  
		log.info("review view......");	
		
		// 하나 조회한 값이랑 상태코드 200을 반환한다.
		return new ResponseEntity<ReviewVO>(
				reviewService.view(revno),HttpStatus.OK);
			
		
	}

	// 수정하기
	@RequestMapping(value = "{revno}",
				 produces = {MediaType.TEXT_PLAIN_VALUE},
				 method= {RequestMethod.PUT, RequestMethod.PATCH})
	public ResponseEntity<String> modify(@PathVariable int revno, @RequestBody ReviewVO revvo) {		
		log.info("review modify......");
		
		// 댓글 수정 성공이면 200과 success 반환, 실패하면 500 코드(INTERNAL_SERVER_ERROR 반환

		return reviewService.modify(revvo) 
					? new ResponseEntity<String>("success", HttpStatus.OK)
				    : new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
	}	
	
	// 삭제하기
	@DeleteMapping(value="{revno}")
	public ResponseEntity<String> remove(@PathVariable int revno) {	
		
		log.info("review remove......");
		
		// 댓글 삭제 성공이면 200과 success 반환, 실패하면 500 코드(INTERNAL_SERVER_ERROR 반환
		
		return reviewService.remove(revno) 
				? new ResponseEntity<String>("success", HttpStatus.OK)
			    : new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
	
	}
	
	
	

}
