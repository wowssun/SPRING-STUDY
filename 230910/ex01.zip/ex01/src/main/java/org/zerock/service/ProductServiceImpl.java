package org.zerock.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.zerock.domain.Criteria;
import org.zerock.domain.ProductImgVO;
import org.zerock.domain.ProductVO;
import org.zerock.mapper.ProductImgMapper;
import org.zerock.mapper.ProductMapper;
import org.zerock.mapper.ReviewMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
public class ProductServiceImpl implements ProductService {

	@Setter(onMethod_ = @Autowired)
	private ProductMapper productMapper;
	
	@Setter(onMethod_ = @Autowired)
	private ReviewMapper reviewMapper;
	
	@Setter(onMethod_ = @Autowired )
	private ProductImgMapper productImgMapper;
	
	@Override
	public List<ProductVO> list() {
		log.info("product list.....");
		
		return productMapper.proSelectAll();
	}

	@Override
	public ProductVO view(String pid) {
		log.info("product view....");
		return productMapper.proSelect(pid);
	}

	@Override
	@Transactional
	public boolean register(ProductVO pvo) {
		log.info("product register..... ");
		
		boolean result = productMapper.proInsert(pvo)==1;
		
		if(pvo.getImgList() != null &&  pvo.getImgList().size() > 0) { // 만약bvo의 attachaList가 있다면
			pvo.getImgList().forEach( pivo -> {  // for문 돌면서 bvolist에 bno를 꺼내서
					pivo.setPid(pvo.getPid());
					productImgMapper.insert(pivo);
				});							 
		}		
				
		return result;
	}

	@Override
	public boolean modify(ProductVO pvo) {
		log.info("product modify...");
		
		// 이미지 모두 삭제
		productImgMapper.deleteAll(pvo.getPid());
		
		boolean result = productMapper.proUpdate(pvo)==1;
		
		if(pvo.getImgList() != null &&  pvo.getImgList().size() > 0) { // 만약bvo의 attachaList가 있다면
			pvo.getImgList().forEach( pivo -> {  // for문 돌면서 bvolist에 bno를 꺼내서
					pivo.setPid(pvo.getPid());
					productImgMapper.insert(pivo);
				});							 
			}		
		
		
		return result;
	}

	@Override
	@Transactional
	public boolean remove(String pid) {
		log.info("product remove....");
		
		// 리뷰 모두 삭제
		reviewMapper.reviewDeleteAll(pid);
		
		// 이미지 모두 삭제
		productImgMapper.deleteAll(pid);
		
		return productMapper.proDelete(pid)==1;
	}

	@Override
	public int totalCount(Criteria cri) {
		log.info("totalCount...");
		return productMapper.totalCount(cri);
	}

	@Override
	public List<ProductVO> list(Criteria cri) {
		log.info(cri);
		return productMapper.proSelectAllPaging(cri);
	}

	@Override
	public List<ProductImgVO> imgList(String pid) {
		log.info("img view");
		return productImgMapper.selectAll(pid);
	}

}
