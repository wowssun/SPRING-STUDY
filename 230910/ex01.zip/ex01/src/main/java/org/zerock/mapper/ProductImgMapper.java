package org.zerock.mapper;

import java.util.List;

import org.zerock.domain.BoardAttachVO;
import org.zerock.domain.ProductImgVO;

public interface ProductImgMapper {


			// 전체 가져오기
			public List<ProductImgVO> selectAll(String pid);
			
			// insert  
			public int insert(ProductImgVO pivo);
			
			// delete
			public int delete(String uuid);

			// deleteAll
			public int deleteAll(String pid);
			
			// 어제자 목록 가져오기
			public List<BoardAttachVO> yesterdayFiles();
	
}
