package org.zerock.mapper;

import org.apache.ibatis.annotations.Insert;

public interface SampleMapper1 {
	
	// insert
	@Insert("INSERT INTO tbl_sample1 VALUES (#{data})")
	public int insertCol(String data);
	

}
