'''
Created on 2023. 9. 7.

@author: user
'''

# 문자 데이터
print("'Hello'")
print('"World!"')
print('\"Hi! ~ \n\tBye~\'')

print('----------------------------------')  # 여러줄 사용
print('''Let's
go''')

print('----------------------------------')   # 탭키나 여러줄 사용 이건 """ 다음에 엔터키가 없음
print(""" 
        to
        the
            """)

print('----------------------------------') # """\는 다음줄에 엔터키가 안들어감
print("""\
        python
        world""")

print('----------------------------------')
print('HA' * 3 )            #HAHAHA
print('Hello ' + 'world!')  #Hello world!
print('welcome ' + '2')     #welcome 2
#print('welcome ' + 3)       #TypeError: can only concatenate str (not "int") to str

print('----------------------------------')
print('Hello'[0])    # H
print('Hello'[1])
print('Hello'[2])
print('Hello'[3])
print('Hello'[4])    # o 
#print('Hello'[5])    # IndexError: string index out of range

print('----------------------------------')   # 역순으로 나옴
print('Hello'[-1])    # o
print('Hello'[-2])
print('Hello'[-3])
print('Hello'[-4])
print('Hello'[-5])      # H

print('----------------------------------')   
print('Hello'[1:3])     # el
print('Hello'[1:])      # ello
print('Hello'[:3])      # Hel

print('----------------------------------')  
print('str(1)   :', type(str(1)) )        # str(1)   : <class 'str'>    정수 -> 문자열
print('int("1") :' , type(int("1")) )     # int("1") : <class 'int'>    문자열 -> 정수

'''
print('----------------------------------')  
name = input('name : ')                     # 사용자에게 입력받을때
age = input('age : ')
print('name : ' , type(name))               # name :  <class 'str'>    문자열
print('age : ' , type(age))                 # age :  <class 'str'>     문자열

print('----------------------------------')  
# print( age > 19 )  사용자에게 입력을 받을때는 모두 문자열이라서 비교가 안된다. TypeError
print(int(age) > 19)
# print(int('age'))    # ValueError: invalid literal for int() with base 10: 'age'  숫자가 아닌 문자열을 정수로 변환하려고해서
'''



print('----------------------------------')  # 자바에서 %s했던것처럼  모두 문자열로
str1 = '{}'.format(1)                       # 1 :  <class 'str'>     
str2 = '{}{}'.format(2, 3)                  # 23 :  <class 'str'>
str3 = '{} {} {}'.format(4, 'Five', False)  # 4 Five False :  <class 'str'>

print(str1 + ' : ' , type(str1))
print(str2 + ' : ' , type(str2))
print(str3 + ' : ' , type(str3))

print('----------------------------------') 
str4 = '{:d}'.format(123); print(str4)       #123
str5 = '{:10d}'.format(123); print(str5)     #       123
str6 = '{:010d}'.format(123); print(str6)    #0000000123

print('----------------------------------') 
str4 =  '{:+10d}'.format(123); print(str4)        #      +123
str5 =  '{:-10d}'.format(-123); print(str5)       #      -123
str6 = '{:=+10d}'.format(123); print(str6)        #+      123
str7 = '{:=-10d}'.format(-123); print(str7)       #-      123

print('----------------------------------') 
str4 =   '{:f}'.format(1.23); print(str4)       #1.230000
str5 = ' {:10f}'.format(1.23); print(str5)      #   1.230000
str6 = '{:010f}'.format(1.23); print(str6)      #001.230000

print('----------------------------------') 
str4 =  '{:+10.2f}'.format(1.23); print(str4)        #     +1.23
str5 =  '{:-10.2f}'.format(-1.23); print(str5)       #     -1.23
str6 = '{:=+10f}'.format(1.23); print(str6)          #+ 1.230000
str7 = '{:=-10f}'.format(-1.23); print(str7)         #- 1.230000

print('----------------------------------') 
str4 =   '{:g}'.format(1.23); print(str4)       #1.23
str5 =   '{:g}'.format(1.0); print(str5)        #1

print('----------------------------------') 
str1 = " Hello "
print(len(str1))    #  길이 공백 포함 7
print(str1.upper() )        # HELLO  
print(str1.lower() )        # hello 
print()
print(str1.lstrip() )       #Hello  왼쪽 공백 제거
print(str1.rstrip() )       # Hello    오른쪽 공백 제거
print(str1.strip() )        #Hello 모든 공백 제거

print('----------------------------------') 
print(str1.isalpha() )  # 알파벳인가? False  공백때문에 false가 나옴
print(str1.isdecimal()) # 숫자인가?   False 
print(str1.strip().isalpha())

print('----------------------------------') 
print(str1)
print(str1.find('l'))         # 왼쪽부터 찾아서 3번째
print(str1.rfind('l'))        # 오른쪽부터 찾아서 왼쪽부터 순서
print('e' in str1)            # 문자열 안에 e가 있는지 True
print('2' in str1)            # 문자열 안에 2가 있는지 False

print('----------------------------------')
str1 = 'Hello World !~'
strs = str1.split(' ' )                 # 공백을 기준으로 자르고 배열로 반환해준다.
print(strs)                             # ['Hello', 'World', '!~']
print(strs[0] == 'Hello')               # 자른 것을 기준으로  인덱스 0번째에 Hello가 들어있는지 True
print(strs[0] == 'hello')




