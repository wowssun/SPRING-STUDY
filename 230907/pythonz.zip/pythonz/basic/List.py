'''
Created on 2023. 9. 7.

@author: user
'''
from array import array
from test.datetimetester import SEC

one = [2, 4, 8]
two = [3, 6, 9]

print(one)
print(one + two)                # [2, 4, 8, 3, 6, 9]
print(one * 3)                  # [2, 4, 8, 2, 4, 8, 2, 4, 8]
print(len(one))                 # 길이 3
print(len(one + two))           # 길이 6

print('--------------------------')
one.append(12);                 print(one)       #  [2, 4, 8, 12]                       리스트에 새로운 요소 추가하기
one.insert(3, 10);              print(one)       #  [2, 4, 8, 10, 12]                   인덱스 3번째 자리에 새로운 요소 10 넣기
one.extend([14, 16, 18, 20] );  print(one)       #  [2, 4, 8, 10, 12, 14, 16, 18, 20]   리스트에 여러개의 요소를 한번에 담기

print('--------------------------')
del one[3];    print(one)                   # [2, 4, 8, 12, 14, 16, 18, 20]   3번째 인덱스에 들어있는 값 삭제   (인덱스)
one.pop(3);    print(one)                   # [2, 4, 8, 14, 16, 18, 20]                                         (인덱스)
one.remove(2); print(one)                   # [4, 8, 14, 16, 18, 20]          들어있는 데이터의 값 삭제         (값)

del one[2:4];   print(one)                     # 인덱스 2번째부터 3번째 값 삭제
del one[:3];    print(one)                     # 0 ~ 2번째 인덱스 지우기, 0부터라서 앞 숫자는 생략 가능하다.
one.clear();    print(one)                     # 남아 있는 데이터 모두 삭제

print('--------------------------')
print(two)                                  # [3, 6, 9]
print( 2 in two )                           # False two안에 2가 들어있나?
print(2 not in two)                         # True two안에 2가 들어있지않나?

print('--------------------------')
for i in range(5) :                         # for 문 i는 초기값 range범위 증가값을 안주면 +1
    print(i)                                # i는 0부터 5까지 
    
print('--------------------------')
for i in two :                             # i는 two 범위에서 end는 옆으로 출력? print는 출력 줄바꿈 반복이다.
    print(i, ' ', end='')

print()
print('--------------------------')
for i in two :                             # i는 two 범위에서 end는 옆으로 출력?
    print(i, ' ', end='\n')

print('--------------------------')
arrayList = [1, 2.2, '삼', True, "false"]   # [1, 2.2, '삼', True, 'false']  배열에는 다른 종류 가능
print(arrayList)

seconArr = [ [ 1, 2, 3],
             [ 4, 5, 6],
             [ 7, 8, 9]]
print(seconArr)                             # [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
print(seconArr[1])                          # 첫번째 행만 가져온다. [4, 5, 6]
print(seconArr[1][1])                       # 첫번째 행과 열  5
     
print('--------------------------')        # 첫번째 for문을 하면  
for i in seconArr:                         # [1, 2, 3] 
    print(i, end=' ')                      # [4, 5, 6]
    print()                                # [7, 8, 9] 
    
# 그럼 여기 나온값들이 모두 i에 123 에 저장되어 있는 값 이제 여기서 i에서 또 0부터 꺼내면  [1, 2, 3]  여기서 하나씩 꺼내는것.

print('--------------------------')        # 이제 for문을 하나 더 사용해서 이중 for문으로 값들만 가져온다. 
for i in seconArr:
    for j in i :                           #  1  2  3 
        print(j,' ', end=' ')              #  4  5  6 
    print()                                #  7  8  9 

print('--------------------------') 































