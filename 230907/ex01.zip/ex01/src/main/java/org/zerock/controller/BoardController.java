package org.zerock.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.zerock.domain.BoardAttachVO;
import org.zerock.domain.BoardVO;
import org.zerock.domain.Criteria;
import org.zerock.domain.PageDTO;
import org.zerock.service.BoardService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/board/*")
@AllArgsConstructor
public class BoardController {
	
	private BoardService boardService;
	
	
	// 첨부 파일 삭제  
	public void deleteFiles(List<BoardAttachVO>attachList) {
		log.info("delete files.......");
		
		if(attachList == null || attachList.size() == 0) {
			return;
		}
		
		attachList.forEach(bavo -> {
			Path file = Paths.get("c:\\upload\\" + bavo.getUpFolder() + "\\"
												 + bavo.getUuid() + "_"
												 + bavo.getFileName());
			log.info("file" + file);
			
			try {
				Files.deleteIfExists(file);
				
				if(Files.probeContentType(file).startsWith("image")) {
					Path thumnail = Paths.get("c:\\upload\\" + bavo.getUpFolder() + "\\s_"
															+ bavo.getUuid() + "_"
															+ bavo.getFileName());
					Files.deleteIfExists(thumnail);
				}
			}catch(IOException e) {
				e.printStackTrace();
			}
					
		});
		
	}
	
	
	@PostMapping("modify")
	@PreAuthorize("principal.username == #bvo.writer")
	public String modify(BoardVO bvo, RedirectAttributes rttr,@ModelAttribute("cri") Criteria cri) {		// 파라미터로 bno를 받아야함.		
		log.info("modify......");
		
		if(boardService.modify(bvo)) {
			rttr.addFlashAttribute("result", "success");    // 여긴 result에 success를 보낸다.
		}
		
	//	int pageNum = cri.getPageNum(); 이렇게 받아서 보내지 말고 밑의 방법처럼 보냄.
	//	int amount = cri.getAmount();	rttr에 담아서 ~~
		
		rttr.addAttribute("pageNum", cri.getPageNum());
		rttr.addAttribute("amount", cri.getAmount());
		rttr.addAttribute("keyword", cri.getKeyword());
		rttr.addAttribute("type", cri.getType());
		
		return "redirect:/board/list";
	}
	
	
	@PostMapping("remove")
	@PreAuthorize("principal.username == #writer")
	public String remove(int bno, RedirectAttributes rttr, @ModelAttribute("cri") Criteria cri) {		// 파라미터로 bno를 받아야함.		
		
		log.info("remove......");
		
		// 미리 리스트를 받아놓고
		List<BoardAttachVO>attachList =  boardService.attachList(bno);		
		
		if(boardService.remove(bno)) {  // 지우기에 성공하면
			
			// 첨부파일 삭제
			deleteFiles(attachList);
			
			rttr.addFlashAttribute("result", "success");    // 그럼 result 이름으로 보내진다. 
		}
			
		//int pageNum = cri.getPageNum();
		//int amount = cri.getAmount();
		
		rttr.addAttribute("pageNum", cri.getPageNum());
		rttr.addAttribute("amount", cri.getAmount());
		rttr.addAttribute("keyword", cri.getKeyword());
		rttr.addAttribute("type", cri.getType());
		
		return "redirect:/board/list" ;
	}
	
	
	// 하나 조회하기, view 처럼 번호 하나를 받아서 수정도 같아서 이렇게 함께 매핑해놓음
	@GetMapping({"view" , "modify"})
	public void view(int bno,Model model, @ModelAttribute("cri") Criteria cri) {		// 파라미터로 bno를 받아야함.
																			    // pageNum이랑 amount를 가지고 있는 cri를 view로 보내야하기 때문에
		log.info("view...... or modify");										// @ModelAttribute 를 사용해서 보낸다.
		model.addAttribute("bvo", boardService.view(bno));						//  여기도 model에 담아서 bvo란 이름으로 받는다.	
	}
		
	
	// 전체 목록 가져오기 + 페이징
	@GetMapping("list")
	public void list(Model model, Criteria cri) {
		
		log.info("list......" + cri);
		model.addAttribute("list", boardService.list(cri));
		
		
		
		model.addAttribute("pageDTO", new PageDTO(cri,boardService.totalCount(cri)));
		
		// pageDTO 객체를 생성해서 cri로 전달한다.
		// model로 넘긴다.
	}
	
	
	
	// jsp 화면이 보이도록 getMapping(주소를 입력해서 들어오는것) 따로 이렇게 처리해야함.
	// void니까 jsp 파일 찾아서 /board/list로
	@GetMapping("register")
	@PreAuthorize("isAuthenticated()")   // 로그인이 되어있냐 안되어있냐 여부
	public void register() {
		log.info("register.....");  // 이건 확인용
		
	}
	
	
	@PostMapping("register")
	@PreAuthorize("isAuthenticated()")
	public String register(BoardVO bvo, RedirectAttributes rttr) {   // 스프링에서 돌려보내기 할때는 이걸쓴다.
		log.info("register....");									// 확인용
		
		if(boardService.register(bvo)) {
			
			rttr.addFlashAttribute("result", bvo.getBno());    // 그럼 result 이름으로 보내진다. bno가
		};
	
		return "redirect:/board/list";
		
		// jsp 파일로 보내면 안되고 mapping 된 list로 보내야 한다. 리턴하고 다시 가는 곳이 같으면  void 사용
		// 그렇지 않을때는 String 으로 
	}
	
	@GetMapping(value = "attachList")
	public ResponseEntity <List<BoardAttachVO>> attachList (int bno){
	 log.info("attachList : " + bno);
	return new ResponseEntity<>(boardService.attachList(bno), HttpStatus.OK);
	}
	
}

