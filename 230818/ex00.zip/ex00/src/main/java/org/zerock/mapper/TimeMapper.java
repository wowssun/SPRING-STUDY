package org.zerock.mapper;

import org.apache.ibatis.annotations.Select;

public interface TimeMapper {
	
	@Select("SELECT sysdate FROM dual")
	public String getTime();
	
	public String getTime2();   // TimeMapper.xml에 id랑 이름을 맞춰야함. 리턴 타입도
	
	

}
