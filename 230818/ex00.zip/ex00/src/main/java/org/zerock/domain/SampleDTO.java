package org.zerock.domain;

import lombok.Data;

@Data  						 // 여기에 만들기
public class SampleDTO {
	
	private String name;
	private int age;
	
	
	

}
