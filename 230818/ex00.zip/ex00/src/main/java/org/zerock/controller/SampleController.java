package org.zerock.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.zerock.domain.SampleDTO;
import org.zerock.domain.SampleDTOList;
import org.zerock.domain.TodoDTO;

import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/sample/*")
@Log4j
public class SampleController {
	
	// 접근은 같다. 들어오는 mapping은 받아오는것과 화면에 처리하는건 다르다
	
	// 화면에 뿌리는건 getMapping으로 한다.
	@GetMapping("exUpload")
	public void exUploadForm(){
		log.info("exUploadForm()................." );
			
		 
	}
	
	// 폼에서 받아와서 처리하는건 이거고 우리는 list로 받기로 함
		@PostMapping("exUpload")
		public void exUpload(ArrayList<MultipartFile> files) {
			log.info("exUpload()................." );
			files.forEach(file -> {
				log.info("name : " + file.getOriginalFilename());
				log.info("size : " + file.getSize());
				log.info("-----------------------------");
			});
			
		}

	

	// json 헤더랑 같이 보내는거?
		@GetMapping("ex07")
		public ResponseEntity<String> ex07() { 
			log.info("ex07().................");
			
			String msg = "{\"name\" : \"Sam\"}";
			HttpHeaders header = new HttpHeaders();
			header.add("Content-Type", "application/json;charaset=UTF-8");
			
			
			return new ResponseEntity<String>(msg, header, HttpStatus.OK);
			
			
		}
	
	
	// json 으로 사용할 때
	@GetMapping("ex06")
	public @ResponseBody SampleDTO ex06() { 
		log.info("ex06().................");
		
		SampleDTO sdto = new SampleDTO();
		sdto.setName("Den");
		sdto.setAge(50);
	
		return sdto;
		
		
	}
		
	
	 // 요청하고 받는 페이지가 다를때 return을 사용해서
	//http://localhost:8090/sample/ex05?name=Ken&age=40&page=2
	// 그럼 ex05로 보냈을때 ex04로 간다.
	// dto가 아닌 애들은 이렇게 보내야한다.
	@GetMapping("ex05")
	public String ex05(SampleDTO dto, @ModelAttribute("page") int page){
		log.info("ex05()................." + dto );
		log.info("ex05()................." + page );
		
		return "/sample/ex04";   
	}
		
//////////////////////////////////////////////////////////
	
	
	@GetMapping("ex04")
	public void ex04(SampleDTO dto, int page) {  //이렇게 보내면 결과 페이지에 param으로 꺼내야 보임
		log.info("ex04()................." + dto );
		log.info("ex04()................." + page );
		
	}
	
	
	
	/*
	 * @InitBinder public void initVinder(WebDataBinder binder) { SimpleDateFormat
	 * dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	 * binder.registerCustomEditor(java.util.Date.class, new
	 * CustomDateEditor(dateFormat, false)); }
	 */
	
	//http://localhost:8090/sample/exTodo?title=Homework&dueDate=2022-11-22
	// 이렇게 보내면 400 에러, 왜냐하면 DTO에 dueDate는 DATE로 선언했기 때문에 java.util.Date
	// 그래서 위와 같은 방법으로 DATE 처리
	@GetMapping("exTodo")
	public void exTodo(TodoDTO todo) {
		log.info("exTodo()................." + todo );
		
	}
	
	
	
	
	// 받는 이름 맞춰줘야 함. class에서 선언한 변수명과 똑같이.아니면 밑에 처럼 변경해주거나
	//%5B는 [, %5D는 ]
	//http://localhost:8090/sample/exDTOList?list%5B0%5D.name=Ann&list%5B1%5D.name=San
	// DTO를 받는 LIST 
	@GetMapping("exDTOList")
	public void exDTOList(SampleDTOList list) {
		log.info("exDTOList()................." + list );
		
	}
	
	
	
	// ArrayList로 받기
		@GetMapping("exList")
		public void exList(@RequestParam("id") ArrayList<String> id) {
			log.info("exList()................." + id );
			
		}
	
	
	// 배열로 받기
	@GetMapping("exArr")
	public void exArr(@RequestParam("id")String[] id) {
		log.info("exArr()................." + Arrays.toString(id));
		
	}
		
	
	//  파라미터로는 name으로 보냈지만 받을때는 다른 이름을 받고싶다면 이렇게
	@GetMapping("ex022")
	public void ex022(@RequestParam("name")String nm,@RequestParam("age") int ageeeee) {
		log.info("ex022()................." + nm);
		log.info("ex022()................." + ageeeee);
	}
	
	
	// int로 받으면 쿼리스트링 파싱안해도 됨.
	@GetMapping("ex02")
	public void ex02(String name, int age) {				//매개변수명과 전달되는 파라미터명과 일치
		log.info("ex02()................." + name);
		log.info("ex02()................." + age);
	}
	
	
	// http://localhost:8090/sample/ex01?name=kim&age=20 이렇게 쿼리를 보냈을때 콘솔에 확인
	
		@GetMapping("ex01")
		public void ex01(SampleDTO dto) {										
			log.info("ex01()................." + dto);
			
			
		}
	
	
	// 경우에 따라서 같이 사용하고 싶을때, 그래서 get, post 할때 모두 다 뜸

	@RequestMapping(value="basicPostGet", method= {RequestMethod.POST, RequestMethod.GET})   
	public void basicPostGet() {										
		log.info("basicPostGet().................");
		
		
	}
	
	
	
//  @PostMapping("basicPost")        이런 방법도 가능	
	@RequestMapping(value="basicPost", method=RequestMethod.POST)   // 얘는 폼태그에서 method로 , 주소창에 바로 쓰는거 x
	public void basicPost() {										// 바로쓰면 405오류 뜬다. post로 쓰고 get작업해서 
		log.info("basicPost().................");
		
		
	}
	
	@RequestMapping("basic")				// 기본 get방식
	public void basicGet() {
		log.info("basicGet().................");
		
		
	}
	
	
	//@RequestMapping("")
	public void basic() {   // 얘도 get 방식
		log.info("basic().................");
		
		
	}
}
