package org.zerock.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration({
	"file:src/main/webapp/WEB-INF/spring/root-context.xml",
	"file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml" })
@Log4j
public class BoardControllerTests {
	@Setter(onMethod_ = @Autowired)
	private WebApplicationContext ctx;
	
	private MockMvc mockMvc;
	
	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.webAppContextSetup(ctx).build();
	}
	
	
	
	
	public void testRemove() throws Exception {
		log.info(mockMvc.perform(MockMvcRequestBuilders
													.post("/board/remove")		// 여긴 post
													.param("bno", "5"))
													   
						.andReturn()
						.getModelAndView()
						.getModelMap()
		);
	}
	
	
	
	
	public void testModify() throws Exception {
		log.info(mockMvc.perform(MockMvcRequestBuilders
													.post("/board/modify")		// 여긴 post
													.param("bno", "3")
													.param("title", "modify title controller")			// 실제는 form으로 들어온 내용들
													.param("content", "modify content controller")	 	// 파라미터로 값이 들어온 내용 확인
													.param("writer", "modifyuser00"))   
						.andReturn()
						.getModelAndView()
						.getModelMap()
		);
	}
	
		
	
	public void testView() throws Exception {
		log.info(mockMvc.perform(MockMvcRequestBuilders
													.get("/board/view")		// 여긴 get	
													.param("bno", "4"))   	// 하나만 가져오는거라서
																			// 파라미터 bno를 가져옴
						.andReturn()
						.getModelAndView()
						.getModelMap()
		);
	}
			

	public void testRegister() throws Exception {
		log.info(mockMvc.perform(MockMvcRequestBuilders
											.post("/board/register")		// 여긴 post
											.param("title", "new title controller")			// 실제는 form으로 들어온 내용들
											.param("content", "new content controller")	 	// 파라미터로 값이 들어온 내용 확인
											.param("writer", "user00"))   
				
						.andReturn()
						.getModelAndView()
						.getModelMap()
		);
	}	
		

	public void testList() throws Exception {
		log.info(mockMvc.perform(MockMvcRequestBuilders.get("/board/list"))   	// 여긴 get
						.andReturn()
						.getModelAndView()
						.getModelMap()
		);
	}
	
	@Test
	public void testListPage() throws Exception {
		log.info(mockMvc.perform(MockMvcRequestBuilders
														.get("/board/list")								// 여긴 get
														.param("amount", "3")			// 실제는 form으로 들어온 내용들
														.param("pageNum", "2")	 	// 파라미터로 값이 들어온 내용 확인
																										)   				
						.andReturn()
						.getModelAndView()
						.getModelMap()
		);
	}
}	




