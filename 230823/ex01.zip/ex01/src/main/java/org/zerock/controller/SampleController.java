package org.zerock.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.zerock.domain.SampleVO;

import lombok.extern.log4j.Log4j;

@RestController
@Log4j
@RequestMapping("/sample/")
public class SampleController {
	
	// http://localhost:8090/sample/product/notebook/1111
	// URL 경로의 일부를 파라미터로 이용
	@GetMapping(value = "product/{cat}/{pid}")
	public String[] getPath(@PathVariable String cat, @PathVariable Integer pid) {
		return new String[] { "category : " + cat,
							  "product : " + pid };
		
	}
	
	//JSON 데이터를 받아서 VO 객체로 반환
	@PostMapping(value="getSvo")
	public SampleVO getSvo(@RequestBody SampleVO svo) {	  // 넘어오는 json데이터를 받을때는 requestBody를사용
		
		log.info("svo : " + svo );
		return svo;
	}
		
	  
	// ResponseEntity 반환
	// - 상태코드, 에러 메시지 등을 데이터와 함께 전달 가능
	@GetMapping(value="check")  		//sample/check로 들어오면
	public ResponseEntity<SampleVO> check(int height, int weight) { //키하고 몸무게를 파라미터로 받아서 int값 2개
		
		SampleVO sv = new SampleVO(111,"Ben","Lee");
		 ResponseEntity<SampleVO> rsen = null;
		
		if(height < 100) {
			rsen = ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(sv);//키가 100 미만이면 http 상태코드 502 bad_Gateway
		}else {
			rsen = ResponseEntity.status(HttpStatus.OK).body(sv);	// 그렇지 않으면 ok 반환
		}
			return rsen;
	
	}


		
	
	// Map 타입 반환
	@GetMapping(value="getMap",
			produces = {MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public Map<String, SampleVO> getMap(){
		Map<String, SampleVO > map = new HashMap<>();
		map.put("six", new SampleVO(666,"sisi","hihi"));
		return map;
	}
	
		
	// List 타입 반환
	
	@GetMapping(value="getList",
					produces = {MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE })
	public List<SampleVO> getList(){
		
		List<SampleVO> samList = new ArrayList<SampleVO>();
			
		samList.add(new SampleVO(333,"woo","a"));
		samList.add(new SampleVO(444,"sss","b"));
		samList.add(new SampleVO(555,"ddd","c"));
		samList.add(new SampleVO(666,"fff","d"));
		samList.add(new SampleVO(777,"ggg","d"));
				
		return samList;
	}
	
	
	
	// VO 객체 반환
	@GetMapping(value="getSample")
	public SampleVO getSample() {
		
		SampleVO sv = new SampleVO(111,"Ben","Lee");
		// SampleVO sv = new SampleVO();
		// sv.setMno(111);
		// ...
		
		log.info("getSample()....");	
		// return new SampleVO(111,"Ben","Lee");
		
		return sv;
	}
	
	@GetMapping(value="getSampleleee",
					produces = {MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE })
		public SampleVO getSampleleee() {
		return new SampleVO(222,"Ken","Jin");
		}
	
	
	
	// 단수 문자열 반환
	@GetMapping(value="getText", 						// 여기서는 value로 처리해서 getText가 들어오면 이 컨트롤 실행
				produces="text/plain; charset=UTF-8")  		// charset 설정하기
	public String getText() {
		log.info("getText().....MIME TYPE : " + MediaType.TEXT_PLAIN_VALUE);
		return " Hello World! 하이!";
	}

}
