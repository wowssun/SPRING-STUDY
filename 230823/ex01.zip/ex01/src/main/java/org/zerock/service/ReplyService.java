package org.zerock.service;

import org.zerock.domain.ReplyVO;

public interface ReplyService {

	// bno로 하나 가져오기
	public ReplyVO view(int rno);
	
	// insert  여기서 boolean으로 true,false로 해도 되고 
	public boolean register(ReplyVO rvo);
	
	// 일단 여기는 boolean으로 해놓고 insertSelectKey 사용했는데
	// 다시 해봐야함.
	
	// delete
	public boolean remove(int rno);
	
	// update
	public boolean modify(ReplyVO rvo);
	
			
	
	
}
