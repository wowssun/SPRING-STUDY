package org.zerock.service;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.BoardVO;
import org.zerock.persistence.BoardMapperTests;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BoardServiceTests {
	
	@Setter(onMethod_ = @Autowired )
	private BoardService boardService;
	
	@Test
	public void testModify() { 
		BoardVO bvo = boardService.view(8);     // 8번 데이터를 가져왔을때 null값이 아니라면
		if(bvo == null) {						// 8번 게시글을 밑의 내용으로 수정
			return;
		}

	//	BoardVO bvo = new BoardVO();
		
		bvo.setTitle("new modifyTitle");					
		bvo.setContent("new modifyContent");				
 		bvo.setWriter("new modifyWriter");
		 
 		boardService.modify(bvo);					// 여기서는 boardServie에 있는거 불러오기 register
		
		log.info("update count :" + boardService.modify(bvo));
		
	}	
	
	
	
	
	public void testRemove() {  // 그럼 결과값이 true로 뜰 것이다. boolean으로 되어 있어서
		log.info("delete count :" + boardService.remove(2));
		
	}	
	
	
	
	public void testView() {
		log.info(boardService.view(2));
		
	}
	
	
	
	public void testList() {
		log.info("---------------------");
		boardService.list().forEach(bvo -> log.info(bvo));	
		log.info("---------------------");
		
		
	}
	
	
	public void testRegister() {
		
		BoardVO bvo = new BoardVO();
		
		bvo.setTitle("new title");					
		bvo.setContent("new content");				
 		bvo.setWriter("new writer");
		 
 		boardService.register(bvo);					// 여기서는 boardServie에 있는거 불러오기 register
		 
 		log.info("생성된 게시물 번호 :" + bvo.getBno());	
		
		
	}
	

	public void testExist() {
		assertNotNull(boardService);
		log.info(boardService);
	}
}
