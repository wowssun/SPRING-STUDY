package org.zerock.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.zerock.domain.BoardVO;
import org.zerock.service.BoardService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/board/*")
@AllArgsConstructor
public class BoardController {
	private BoardService boardService;
	
	@PostMapping("modify")
	public String modify(BoardVO bvo, RedirectAttributes rttr) {		// 파라미터로 bno를 받아야함.		
		log.info("modify......");
		
		if(boardService.modify(bvo)) {
			rttr.addFlashAttribute("result", "success");    // 여긴 result에 success를 보낸다.
		}
		
		return "redirect:/board/list";
	}
	
	
	
	@PostMapping("remove")
	public String remove(int bno, RedirectAttributes rttr) {		// 파라미터로 bno를 받아야함.		
		log.info("remove......");
		boardService.remove(bno);	
		rttr.addFlashAttribute("result", "success");    // 그럼 result 이름으로 보내진다. bno가
		
		return "redirect:/board/list";
	}
	
	
	@GetMapping("view")
	public void view(int bno,Model model) {		// 파라미터로 bno를 받아야함.		
		log.info("view......");
		model.addAttribute("bvo", boardService.view(bno));		//  여기도 model에 담아서 bvo란 이름으로 받는다.
	}
		
	
	@GetMapping("list")
	public void list(Model model) {
		log.info("list......");
		model.addAttribute("list", boardService.list());
	}
	
	@PostMapping("register")
	public String register(BoardVO bvo, RedirectAttributes rttr) {   // 스프링에서 돌려보내기 할때는 이걸쓴다.
		log.info("register....");									// 선언하고
		boardService.register(bvo);
		rttr.addFlashAttribute("result", bvo.getBno());    // 그럼 result 이름으로 보내진다. bno가
	
		return "redirect:/board/list";
		
		// jsp 파일로 보내면 안되고 mapping 된 list로 보내야 한다. 리턴하고 다시 가는 곳이 같으면  void 사용
		// 그렇지 않을때는 String 으로 
	}
}




