package org.zerock.service;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.log;

import java.util.List;

import org.springframework.stereotype.Service;
import org.zerock.domain.BoardVO;
import org.zerock.mapper.BoardMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;



@Service     												// 서비스단은 서비스 어노테이션
@AllArgsConstructor											// 생성자
@Log4j
public class BoardServiceImpl implements BoardService {
	
	private BoardMapper boardMapper;						// boardMapper에 메서드들을 사용해야 하니까 객체 선언
															// 그 다음에는 root context에 가서
		

	@Override
	public List<BoardVO> list() {
		
		 log.info("list.....");
		return boardMapper.selectAll();
	}

	@Override
	public BoardVO view(int bno) {
		
		log.info("view....");
	
		return boardMapper.select(bno);
	}

	@Override
	public boolean register(BoardVO bvo) {	
		log.info("register..." + bvo);
		
		return boardMapper.insertSelectKey(bvo) ==1;
			
		
	}

	@Override
	public int insertSelectKey(BoardVO bvo) {
	
		return 0;
	}

	@Override
	public boolean remove(int bno) {
		
		log.info("remove...");
		return boardMapper.delete(bno) ==1;
	}

	@Override
	public boolean modify(BoardVO bvo) {
		
		log.info("modify...");
		
		return boardMapper.update(bvo) == 1;
	}

}
