package org.zerock.mapper;

import java.util.List;

import org.zerock.domain.BoardVO;

public interface BoardMapper {
	
	// 전체 가져오기
	public List<BoardVO> selectAll();
	
	// bno로 하나 가져오기
	public BoardVO select(int bno);
	
	// insert  여기서 boolean으로 true,false로 해도 되고 
	public void insert(BoardVO bvo);
	
	// 시퀀스 하나 미리 저장해놓고 ,insert  여기서 boolean으로 true,false로 해도 되고 
	public int insertSelectKey(BoardVO bvo);
	
	// delete
	public int delete(int bno);
	
	// update
	public int update(BoardVO bvo);

}
