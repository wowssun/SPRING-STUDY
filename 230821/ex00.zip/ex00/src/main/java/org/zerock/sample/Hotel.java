package org.zerock.sample;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Component
//@AllArgsConstructor    // 모든 필드 자동 인젝션 
@ToString
@Getter
@RequiredArgsConstructor    // final 또는 @NonNull 필드 인젝션
public class Hotel {
	@NonNull
	private Chef chef;
	
	// component는 스프링
	// 밑에 나머지는 lombok 라이브러리

//  명시적 생성자   원래 이렇게 뜨는데 위에 @AllArgsConstructor 이걸 쓰면 생성자 생성
//	public Hotel(Chef chef) {
//		this.chef = chef;
//	}

	
	
	
}
