package org.zerock.domain;

import java.util.List;

import lombok.Data;

@Data
public class SampleDTOList {
	
	// SampleDTO를 갖는 list
	private List<SampleDTO> list;

}
