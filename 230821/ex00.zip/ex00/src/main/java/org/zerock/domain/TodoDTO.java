package org.zerock.domain;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class TodoDTO {
	
	private String title;
	
	@DateTimeFormat(pattern="yyyy-MM-dd")   // 아니면 이렇게 처리 해야한다. initbinder 대신 컨트롤러에 있음
	private Date dueDate;

}
