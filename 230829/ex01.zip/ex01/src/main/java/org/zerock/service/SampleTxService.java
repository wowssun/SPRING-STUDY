package org.zerock.service;

public interface SampleTxService {


	public void txTest(String data);
}
