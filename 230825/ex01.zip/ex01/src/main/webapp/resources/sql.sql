CREATE TABLE tbl_reply (
    rno     NUMBER  CONSTRAINT pk_reply PRIMARY KEY,
    bno     NUMBER  CONSTRAINT fk_reply REFERENCES tb1_board(bno) NOT NULL,
    reply   VARCHAR2(1000) NOT NULL,
    replyer VARCHAR2(50)   NOT NULL,
    regDate     DATE    DEFAULT SYSDATE,
    updateDate  DATE    DEFAULT SYSDATE
);

CREATE INDEX idx_reply
ON tbl_reply(bno DESC, rno ASC);

CREATE SEQUENCE seq_reply NOCACHE;

insert



CREATE TABLE tb1_board (
    bno number constraint pk_board primary key,
    title varchar2(200) not null,
    content varchar2(200) not null,
    writer varchar2(200) not null,
    regdate date default sysdate,
    updatedate date default sysdate );
    
 create sequence seq_board nocache;
 
 insert into tb1_board(bno,title, content, writer)
 values(seq_board.nextval, '테스트 제목', '테스트 내용', 'user00');
 
 select * from tb1_board;
 SELECT * FROM tbl_reply;
 
 SELECT * FROM tb1_board 
 ORDER BY bno DESC;
 
 
 SELECT  bno, title, content, writer, regDate, updateDate
    FROM ( SELECT /*+INDEX_DESC(tb1_board pk_board) */
    			rownum rn, bno, title, content, writer,
    			regDate, updateDate
    			FROM tb1_board
    			WHERE rownum <= 3 * 2)
  	WHERE rn > 3 * (2-1);
 
 
 commit;
 