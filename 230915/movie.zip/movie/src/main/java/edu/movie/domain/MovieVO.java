package edu.movie.domain;

import lombok.Data;

@Data
public class MovieVO {

	private String title;    	// 영화 제목
	private String img;			// 영화 이미지
	private String openDate; 	// 개봉일
	private String percent;		// 예매율
}
