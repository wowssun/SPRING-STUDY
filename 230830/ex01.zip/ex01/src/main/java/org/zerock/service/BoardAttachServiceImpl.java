package org.zerock.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.zerock.domain.BoardAttachVO;
import org.zerock.mapper.BoardAttachMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;


@Service     												// 서비스단은 서비스 어노테이션
@AllArgsConstructor											// 생성자
@Log4j
public class BoardAttachServiceImpl implements BoardAttachService {

	private BoardAttachMapper boardAttachMapper;	
	
	@Override
	public List<BoardAttachVO> list(int bno) {
		log.info("attachlist.....");
		
		return boardAttachMapper.selectAll(bno);
	}

	@Override
	public boolean add(BoardAttachVO bavo) {
		
		log.info("attach add.....");
		
		return boardAttachMapper.insert(bavo)==1;
	}

	@Override
	public boolean remove(String uuid) {
	
		log.info("attach remove.....");
		return boardAttachMapper.delete(uuid) ==1;
	}

}
