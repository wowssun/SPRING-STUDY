package org.zerock.mapper;

import java.util.List;

import org.zerock.domain.BoardAttachVO;

public interface BoardAttachMapper {
	
		// 전체 가져오기
		public List<BoardAttachVO> selectAll(int bno);
		
		// insert  
		public int insert(BoardAttachVO bavo);
		
		// delete
		public int delete(String uuid);

}
