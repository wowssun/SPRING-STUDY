package edu.movie.domain;

import lombok.Data;

@Data
public class MovieVO {

	private String title;    	// 영화 제목
	private String img;			// 영화 이미지
	private String openDate; 	// 개봉일
	private String percent;		// 예매율
	private String director;    // 감독
	private String actor;       // 배우
	private String info;		// 영화정보
	private String href;		// 상세정보 주소
}
