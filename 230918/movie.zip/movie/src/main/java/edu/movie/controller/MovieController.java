package edu.movie.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import edu.movie.domain.MovieVO;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/movie/")
public class MovieController {
	
	// 지정된 url의 html 가져오기
	
	@GetMapping("chart") // movie/chart get 매핑
	public List<MovieVO> chart(Model model){		// Movie List로 반환하는 chart()
		
		 List<MovieVO> movieList = new ArrayList<MovieVO>();
		 
		 String  cgv = "http://www.cgv.co.kr/movies/?lt=1&ft=0";
		 try {
			Document doc = Jsoup.connect(cgv).get();			// jsoup으로 Document import 하기
			// log.info(doc);
			Elements charDiv = doc.select("div.sect-movie-chart");    // jsoup으로 Elements import 하기  div의 클래스 ckwdkdhrl
			Elements chartOL = charDiv.eq(0).select("ol");
			
			// log.info(chartOL.size());     // 여기서는 ol이 3개 나옴
			
			for(int i = 0; i<chartOL.size(); i++ ) {
				Elements charLI = chartOL.eq(i).select("li");
					// log.info(charLI.size());    // ol안에 있는 각각의 li 개수
				for(int j = 0; j < charLI.size(); j++) {
					String title = charLI.eq(j).select("strong.title").text();		
					String img = charLI.eq(j).select("div.box-image img").attr("src");
					String href = charLI.eq(j).select("div.box-image a").attr("href");
					String percent = charLI.eq(j).select("strong.percent").text();
					String openDate = charLI.eq(j).select("span.txt-info").text();
					
					//log.info(title + img + percent.split("율")[1] + openDate.split(" ")[0]);
					// log.info(href);
					
					// movieVO에 담기
					MovieVO mvo = new MovieVO();
					mvo.setTitle(title);
					mvo.setImg(img);
					mvo.setPercent(percent.split("율")[1]);
					mvo.setOpenDate(openDate);
					mvo.setHref(href);
						
					movieList.add(mvo);
							
				} // for end
					
			}  // for end
						
		} catch (IOException e) {
			e.printStackTrace();
		}   
		 model.addAttribute("movieList", movieList);
		return movieList;
	}   // cart end
			
	
	@GetMapping("detail")
	@ResponseBody      // ajax로 보낸거라서 실행은 되는데 계속 404가 떠서 이렇게 처리해주었다. 
	public MovieVO detail (String href) {
		
		//log.info(href);
		MovieVO movo = new MovieVO();	
		// 우선 한 페이지로 정보 오는지 테스트해보고
		// 사진이랑 제목 클릭하면 a태그 href값이 넘어오도록 해보기.
		 String  cgvView = "http://www.cgv.co.kr/movies/detail-view/?" + href;
		//  http://www.cgv.co.kr/movies/detail-view/?midx=87335
		// /movies/detail-view/?midx=87335
		 try {
			Document doc = Jsoup.connect(cgvView).get();			// jsoup으로 Document import 하기
			 //log.info(doc);
			Elements baseContent = doc.select("div.sect-base-movie");
			Elements spec = baseContent.select(".spec dd");

			String title = baseContent.select("div.title strong").text();
			String img = baseContent.select("div.box-image img").attr("src");
			String percent = baseContent.select(".percent span").text();
		
			String director = spec.eq(0).text();
			String actor = spec.eq(2).text();
			String info = spec.eq(4).text();
			String openDate = spec.eq(5).text();
			
			movo.setTitle(title);
			movo.setImg(img);
			movo.setPercent(percent);
			movo.setDirector(director);
			movo.setActor(actor);
			movo.setInfo(info);
			movo.setOpenDate(openDate);
			
			//log.info("감" + director +"배"+ actor+ "정"+ info +"개"+ openDate);
						
		} catch (IOException e) {
			e.printStackTrace();
		}   
		log.info(movo);	
		
		return movo;
	}
	
	@GetMapping("view")
	public MovieVO view (MovieVO movo, Model model) {
		
		
		
		
		
		
		
		
		return movo;
	}
	
}
