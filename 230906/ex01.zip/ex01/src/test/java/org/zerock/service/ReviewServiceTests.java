package org.zerock.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.BoardVO;
import org.zerock.domain.Criteria;
import org.zerock.domain.ReviewVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ReviewServiceTests {
	
	@Setter(onMethod_ =@Autowired )
	private ReviewService reviewService;
	
	
	
	
	 // 하나 조회
	public void testView() {   // 성공
		log.info(reviewService.view(3));
		
	}
	
	// 등록
	public void testRegister() {   // 성공
		
		ReviewVO revvo = new ReviewVO();
		
		revvo.setPid("P1241");					
		revvo.setReview("new reply");				
		revvo.setReviewer("new replyer");
		 
		reviewService.add(revvo);					
		 
 		log.info("생성된 댓글 번호 :" + revvo.getRevno());	
		
		
	}
		
	// 삭제 // 성공
	public void testRemove() {  // 그럼 결과값이 true로 뜰 것이다. boolean으로 되어 있어서
		log.info("delete count :" + reviewService.remove(2));
		
	}
	
	@Test			
	public void testModify() { 
		ReviewVO rvvo = reviewService.view(5);     // 8번 데이터를 가져왔을때 null값이 아니라면
		if(rvvo == null) {						// 8번 게시글을 밑의 내용으로 수정
			return;
		}

	//	BoardVO bvo = new BoardVO();
		
		rvvo.setReview("modify reply");	
		
		
		reviewService.modify(rvvo);					// 여기서는 boardServie에 있는거 불러오기 register
		
		log.info("update count :" +reviewService.modify(rvvo));

	}	
	


}
