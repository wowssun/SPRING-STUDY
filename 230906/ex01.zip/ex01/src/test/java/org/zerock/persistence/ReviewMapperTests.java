package org.zerock.persistence;

import org.apache.ibatis.annotations.Select;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.BoardVO;
import org.zerock.domain.Criteria;
import org.zerock.domain.ReplyVO;
import org.zerock.domain.ReviewVO;
import org.zerock.mapper.ReviewMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ReviewMapperTests {
	
	@Setter(onMethod_ = @Autowired )
	private ReviewMapper reviewMapper;
	
	// 전체 목록
	public void testSelecAll() {  						// 성공
		
		Criteria cri = new Criteria();
		log.info("---------------------------");
		reviewMapper.reviewSelectAllPaging("P1234",cri).forEach(pvo -> log.info(pvo));			// 람다식 사용해서 람다식 사용하는거
		log.info("---------------------------");
		
	}
	
	// 등록
	@Test
	public void testInsert() {			// 성공			// insert
		
		ReviewVO revvo = new ReviewVO();		
		 
		revvo.setPid("P1235");					// 원래는 값 입력받는걸로 자동
		revvo.setReview("new review");				// 여기서는 test 해보려고
		revvo.setReviewer("new reviewer");
		 
		 reviewMapper.reviewInsert(revvo);					// boardMapper에 inset에 bvo 담아서 호출
		 
		 log.info(revvo);								// log에 찍어보기
		
	}
	
	// 하나 조회
	public void testSelect() {  // 성공
		log.info("---------------------------");
		reviewMapper.reviewSelect(1);					// 하나 가져오는건 매개변수 사용
		log.info("---------------------------");
		
	}
	
	
	
	
	
	
	  // 삭제
	public void delete() {		 // 성공					// delete
		
		reviewMapper.reviewDelete(1); 
		// log.info("delete count : " + boardMapper.delete(1)); 로 확인 가능
		
	}
	
	// 수정
	public void update() {			  // 성공				 
		
		ReviewVO revvo = new ReviewVO();				
		 
		revvo.setRevno(1);
		revvo.setReview("리뷰내용 수정 ");
		
		log.info("update count : " +reviewMapper.reviewUpdate(revvo));  // 로 확인 가능 이렇게하면 업데이는 되는 개수
		 														// mapper에서 int로 return맞춰놓음
		
	}
	
	

}
