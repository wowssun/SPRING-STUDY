package org.zerock.security;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({
	"file:src/main/webapp/WEB-INF/spring/root-context.xml",
	"file:src/main/webapp/WEB-INF/spring/security-context.xml" })
@Log4j
public class MemberTests {
	
	@Setter(onMethod_ =@Autowired )
	private DataSource dataSource;
	
	@Setter(onMethod_ = @Autowired)
	private PasswordEncoder pwEncoder;

	@Test
	public void testInsertAuth() {
	      String sql ="INSERT INTO tbl_member_auth(id, auth) VALUES(?, ?)";
	      
	    //PreparedStatement를 이용하여
	      try(Connection con = dataSource.getConnection();
	            PreparedStatement pstmt = con.prepareStatement(sql)) {
	                for(int i=0; i<100; i++) {
	                	
	                      //0 ~ 79 일반사용자 ROLE_USER
	                  
	                   if(i<80) {
	                      pstmt.setString(1, "user"+i);
	                      pstmt.setString(2, "ROLE_USER");
	                   }
	                   //80 ~ 89 멤버 ROLE_MEMBER
	                   else if(i<90) { 
	                      pstmt.setString(1, "member"+i);
	                      pstmt.setString(2, "ROLE_MEMBER");
	                   }
	                   //90 ~ 99 관리자 ROLE_ADMIN
	                   else {  
	                      pstmt.setString(1, "admin"+i);
	                      pstmt.setString(2, "ROLE_ADMIN");
	                   }
	                   pstmt.executeUpdate();
	                }
	               
	            }catch (SQLException e) {
	               e.printStackTrace();
	         }
	   }
	     	

	public void testInsertMember() {
	      String sql = "INSERT INTO tbl_member(id, pw, name) VALUES(?, ?, ?)";
	      
	      //PreparedStatement를 이용하여
	      try(Connection con = dataSource.getConnection();
	            PreparedStatement pstmt = con.prepareStatement(sql)) {
	                for(int i=0; i<100; i++) {
	                   pstmt.setString(2, pwEncoder.encode("1111"));
	                   //tbl_member 테이블에 테스트 데이터 추가    
	                   //0 ~ 79 일반사용자 user0 ~ user79
	                   if(i<80) {
	                      pstmt.setString(1, "user"+i);
	                      pstmt.setString(3, "일반사용자"+i);
	                   }
	                   else if(i<90) { //80 ~ 89 멤버 member80 ~ member89
	                      pstmt.setString(1, "member"+i);
	                      pstmt.setString(3, "멤버"+i);
	                   }
	                   else {  //90 ~ 99 관리자 admin90 ~ admin99
	                      pstmt.setString(1, "admin"+i);
	                      pstmt.setString(3, "관리자"+i);
	                   }
	                   pstmt.executeUpdate();
	                }
	               
	            }catch (SQLException e) {
	               e.printStackTrace();
	         }
	   }

	
	
		

}
