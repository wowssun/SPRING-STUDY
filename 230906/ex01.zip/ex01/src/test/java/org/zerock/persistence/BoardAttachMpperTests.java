package org.zerock.persistence;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.BoardAttachVO;
import org.zerock.mapper.BoardAttachMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BoardAttachMpperTests {

	@Setter(onMethod_ = @Autowired )
	private BoardAttachMapper boardattachMapper;
	
	
	public void delete() {							// delete
			
		boardattachMapper.delete("uuid"); 
		// uuid는 String
			
		}
	
	public void testInsert() {						// insert
		
		 BoardAttachVO bavo = new BoardAttachVO();				// BoardVO 객체 생성
		 
		 
		 // 여기 확인해보기
		 bavo.setBno(13);
		 bavo.setFileName("파일");
		 bavo.setImage(true);
		 bavo.setUpFolder("폴더");
		 bavo.setUuid("uuid");
		 
		 boardattachMapper.insert(bavo);					// boardMapper에 inset에 bvo 담아서 호출
		 
		 log.info(bavo);								// log에 찍어보기
		
	}
	
	
	public void testSelecAll() {
		log.info("---------------------------");
		boardattachMapper.selectAll(13).forEach(bavo -> log.info(bavo));			// 람다식 사용해서 람다식 사용하는거
		log.info("---------------------------");
		
	}
	
	@Test
	public void deletAll() {   // 
		
	
		log.info(boardattachMapper.deleteAll(108));
	}

}
