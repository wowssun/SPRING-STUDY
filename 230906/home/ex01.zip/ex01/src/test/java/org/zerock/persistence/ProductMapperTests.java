package org.zerock.persistence;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.ProductVO;
import org.zerock.mapper.ProductMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ProductMapperTests {
	
	@Setter(onMethod_ = @Autowired )
	private ProductMapper productMapper;
	
	
	public void insertTest() {  // 성공
		ProductVO pvo = new ProductVO();
		
		pvo.setPid("P1238");
		pvo.setPname("초코파이");
		pvo.setPrice(3000);
		pvo.setDescription("초코파이임");
		pvo.setMaker("오리온");
		pvo.setCategory("과자");
		pvo.setStock(100);
		pvo.setCondition("new");
		pvo.setPimage("choco.png");
		
		productMapper.proInsert(pvo);
		
		log.info("등록 성공 " + pvo);
		
		
	}
	
	
	public void selectTest() {   //성공
		
		log.info("---------------------------");
		productMapper.proSelect("P1234");									// 하나 가져오는건 매개변수 사용
		log.info("---------------------------");
		
	}
	
	
	public void selectAllTest() {  // 성공
		log.info("---------------------------");
		productMapper.proSelectAll().forEach(pvo -> log.info(pvo));			// 람다식 사용해서 람다식 사용하는거
		log.info("---------------------------");
		
	}
	
	
	public void updateTest() {
		ProductVO pvo = new ProductVO();
		
		pvo.setPid("P1238");
		pvo.setPname("초코파이 vs 오예스");
		pvo.setPrice(3000);
		pvo.setDescription("초코파이 전자레인지에 돌려먹기");
		pvo.setMaker("오리온");
		pvo.setCategory("빵?");
		pvo.setStock(100);
		pvo.setCondition("new");
		pvo.setPimage("choco.png");
		
		if(productMapper.proUpdate(pvo)==1) {
			log.info("수정 성공");
		};
		
		
		
		
	}
	
	
	public void deleteTest() {   // 성공
		if(productMapper.proDelete("P1234")==1) {
		log.info("삭제 성공");
		}
		
	}
	
	// 리뷰 수 업데이트
	@Test	
	public void replyCntTest() {   // 성공
		
		// P1234에 해당하는 리뷰가 하나 업데이트
		log.info(productMapper.updateReviewCnt(1, "P1234"));
	}
	
	
	
	

}
