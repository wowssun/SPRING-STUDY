package org.zerock.controller;

import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import lombok.extern.log4j.Log4j;


@Controller
@Log4j
public class SecurityController {
	
	
	@GetMapping("/sample/member2")
	@PreAuthorize("hasAnyRole('ROLE_MEMBER', 'ROLE_ADMIN')")   // 이건 role이 있냐
	public void member2() {
		log.info("sample member2... @PreAuthorize - 멤버전용");
		
	}
	
	@GetMapping("/sample/admin2")
	@Secured("ROLE_ADMIN")
	public void admin2() {
		log.info("sample admin... - @Secured 어드민 전용");
		
	}
	
	
	@GetMapping("/sample/all")
	public void all() {
		log.info("sample all...");
	}
	
	@GetMapping("/sample/member")
	public void member() {
		log.info("sample member...");
		
	}
	
	@GetMapping("/sample/admin")
	public void admin() {
		log.info("sample admin...");
		
	}

}
