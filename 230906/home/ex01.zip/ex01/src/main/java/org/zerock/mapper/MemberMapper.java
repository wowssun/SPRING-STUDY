package org.zerock.mapper;



import org.zerock.domain.MemberVO;

public interface MemberMapper {

	// mapper와 type 맞춰서
	public MemberVO select(String id);
}
