package org.zerock.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cglib.core.DefaultNamingPolicy;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartRequest;
import org.zerock.domain.Criteria;
import org.zerock.domain.ProductVO;
import org.zerock.mapper.ProductMapper;
import org.zerock.mapper.ReviewMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
public class ProductServiceImpl implements ProductService {

	@Setter(onMethod_ = @Autowired)
	private ProductMapper productMapper;
	
	@Setter(onMethod_ = @Autowired)
	private ReviewMapper reviewMapper;
	
	@Override
	public List<ProductVO> list() {
		log.info("product list.....");
		
		return productMapper.proSelectAll();
	}

	@Override
	public ProductVO view(String pid) {
		log.info("product view....");
		return productMapper.proSelect(pid);
	}

	@Override
	public boolean register(ProductVO pvo) {
		log.info("product register..... ");
			
		return productMapper.proInsert(pvo)==1;
	}

	@Override
	public boolean modify(ProductVO pvo) {
		log.info("product modify...");
		
		return productMapper.proUpdate(pvo)==1;
	}

	@Override
	public boolean remove(String pid) {
		log.info("product remove....");
		
		// 리뷰 모두 삭제
		reviewMapper.reviewDeleteAll(pid);
		return productMapper.proDelete(pid)==1;
	}

	@Override
	public int totalCount(Criteria cri) {
		log.info("totalCount...");
		return productMapper.totalCount(cri);
	}

	@Override
	public List<ProductVO> list(Criteria cri) {
		log.info(cri);
		return productMapper.proSelectAllPaging(cri);
	}

}
