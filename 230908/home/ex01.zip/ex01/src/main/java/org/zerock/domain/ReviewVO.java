package org.zerock.domain;

import java.util.Date;

import lombok.Data;

@Data
public class ReviewVO {
	
	private int revno;    
    private String pid;    
    private String review;  
    private String reviewer;
    private Date regDate;    
    private Date updateDate; 

}
