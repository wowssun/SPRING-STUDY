package org.zerock.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.zerock.domain.BoardAttachVO;
import org.zerock.domain.BoardVO;
import org.zerock.domain.Criteria;
import org.zerock.mapper.BoardAttachMapper;
import org.zerock.mapper.BoardMapper;
import org.zerock.mapper.ReplyMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;



@Service     												// 서비스단은 서비스 어노테이션
@Log4j
public class BoardServiceImpl implements BoardService {
	
	  @Setter(onMethod_ = @Autowired)
	   private BoardMapper boardMapper;						// 생성자 넣으니까 안된다. 다시 setter로 변경
		
	   @Setter(onMethod_ = @Autowired)
	  private BoardAttachMapper boardAttachMapper;				// 그 다음에는 root context에 가서
	   
	   @Setter(onMethod_ = @Autowired)
	   private ReplyMapper replyMapper;
	   
	
		
	@Override
	@Transactional   // 두 테이블이 같이 움직여야 하니까 어노테이션 필수!
	public boolean register(BoardVO bvo) {	
		log.info("register..." + bvo);
		
		boolean result = boardMapper.insertSelectKey(bvo) ==1;
		
		
		if(bvo.getAttachList() != null &&  bvo.getAttachList().size() > 0) { // 만약bvo의 attachaList가 있다면
				  bvo.getAttachList().forEach( bavo -> {  // for문 돌면서 bvolist에 bno를 꺼내서
						bavo.setBno(bvo.getBno());
						boardAttachMapper.insert(bavo);
					});						
		 
	}
		return result;			
		
	}
			
	@Override
	public List<BoardVO> list() {
		
		 log.info("list.....");
		return boardMapper.selectAll();
	}

	@Override
	public BoardVO view(int bno) {
		
		log.info("view....");
					
	//	return boardMapper.select(bno);
	    return boardMapper.select(bno);
				
	} 



	@Override
	public int insertSelectKey(BoardVO bvo) {
	
		return 0;
	}

	@Override
	@Transactional
	public boolean remove(int bno) {
		
		log.info("remove...");
		
		// 게시판 번호를 모두 가지고 있어서 미리 삭제를 해주고 게시판삭제.
		
		// 댓글 모두 삭제  --> 여기 mapper로 만들어서 처리했습니다.
		replyMapper.reDeleteAll(bno);
		
		// 첨부파일 모두 삭제
		boardAttachMapper.deleteAll(bno);
		
		//baMapper.delete(uuid) ==1;
		
		return boardMapper.delete(bno) ==1;
		
		
	}

	@Override
	@Transactional
	public boolean modify(BoardVO bvo) {
		
		log.info("modify...");
		
		// 첨부파일 모두 삭제
		boardAttachMapper.deleteAll(bvo.getBno());
		
		boolean result =  boardMapper.update(bvo) == 1; 		// 게시물 수정
		
		// 첨부파일이 있으면 등록
		if(bvo.getAttachList() != null  &&  bvo.getAttachList().size() > 0) {  // 만약 bvo의 attachaList가 있다면 
			
			bvo.getAttachList().forEach(bavo -> { bavo.setBno(bvo.getBno());   // for문 돌면서 bvolist에 bno를 꺼내서
			
			boardAttachMapper.insert(bavo);
		});
	}	
		return result;
			
	}
	

	@Override
	public int totalCount(Criteria cri) {
		log.info("totalCount...");
		
		return boardMapper.totalCount(cri);
	}

	@Override
	public List<BoardVO> list(Criteria cri) {
		log.info(cri);
		return boardMapper.selectAllPaging(cri);
	}

	@Override
	public List<BoardAttachVO> attachList(int bno) {
		
		log.info("attach view");
		
		return boardAttachMapper.selectAll(bno);
	}


	/*
	 * @Override public boolean replyCntmodify(int amount, int bno) {
	 * 
	 * log.info("amount : " + amount); log.info("bno : " + bno);
	 * 
	 * return boardMapper.updateReplyCnt(amount, bno) == 1; }
	 */

}
