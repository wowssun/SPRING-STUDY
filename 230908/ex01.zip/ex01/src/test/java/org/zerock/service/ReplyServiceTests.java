package org.zerock.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.ReplyVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ReplyServiceTests {
	
	@Setter(onMethod_ = @Autowired )
	private ReplyService replyServiece;

	
	public void testRegister() {
			
			ReplyVO rvo = new ReplyVO();
			
			rvo.setBno(13);					
			rvo.setReply("new reply");				
			rvo.setReplyer("new replyer");
			 
			replyServiece.add(rvo);					// 여기서는 boardServie에 있는거 불러오기 register
			 
	 		log.info("생성된 댓글 번호 :" + rvo.getRno());	
			
			
		}
	
	@Test
	public void testView() {
		log.info(replyServiece.view(37));
		
	}
	
	
	
}
