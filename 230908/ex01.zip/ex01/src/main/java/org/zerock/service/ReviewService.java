package org.zerock.service;


import org.zerock.domain.Criteria;
import org.zerock.domain.ReviewPageDTO;
import org.zerock.domain.ReviewVO;

public interface ReviewService {
	
	
	
	 // insert  여기서 boolean으로 true,false로 해도 되고
		public boolean add(ReviewVO revo);
	
		//  revno로 하나 가져오기 (조회)
		public ReviewVO view(int revno);
		
		
		// delete
		public boolean remove(int revno);
			
		// update
		public boolean modify(ReviewVO revvo);
		
		// 전체 목록 페이징
		public ReviewPageDTO list(String pid, Criteria cri);

}
