package org.zerock.domain;

import lombok.Data;

@Data
public class ProductImgVO {

		private String pid;
		private String uuid;
		private String upFolder;
		private String fileName;
		private boolean image;
}
