package org.zerock.service;

import java.util.List;

import org.zerock.domain.BoardAttachVO;
import org.zerock.domain.Criteria;
import org.zerock.domain.ProductImgVO;
import org.zerock.domain.ProductVO;

public interface ProductService {

	
		// 상품 전체 목록 
		public List<ProductVO> list();
		
		// 상품 조회
		public ProductVO view(String pid);
		
		// 상품 등록
		public boolean register(ProductVO pvo);
		
		// 상품 수정
		public boolean modify(ProductVO pvo);
		
		// 상품 삭제
		public boolean remove(String pid);
	
		// 전체 게시물 수
		public int totalCount(Criteria cri);
				
		// 전체 목록 페이징
		public List<ProductVO> list(Criteria cri);
	
		// 첨부파일 전체 가져오기
		public List<ProductImgVO> imgList(String pid);
	
	
	
}
