package org.zerock.service;

import java.util.List;

import org.zerock.domain.ProductImgVO;

public interface ProductImgService {

	
			// 전체 가져오기
				public List<ProductImgVO> list(String pid);
			
				// insert   
				public boolean add(ProductImgVO pivo);
				
				// delete
				public boolean remove(String uuid);
	
}
