package org.zerock.domain;

import java.util.List;

import lombok.Data;

@Data
public class ProductVO  {
	
	// private static final long serialVersionUID = 1L; 
	
	private String pid;						// 제품 코드
	private String pname; 					// 제품 이름
	private int  price;						// 제품 가격
	private String description;				// 설명
	private String maker;					// 제조사
	private String category;				// 분류
	private int stock;						// 재고 수량
	private String condition;				// 신상품 | 중고품 | 재생품
	private String pimage;					// 이미지 파일명
	private List<ProductImgVO> imgList;		// 등록하는 파일 이미지 
	
	
	
}
