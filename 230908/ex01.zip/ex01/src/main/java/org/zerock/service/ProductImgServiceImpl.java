package org.zerock.service;

import java.util.List;
import org.zerock.domain.ProductImgVO;
import org.zerock.mapper.ProductImgMapper;

import lombok.extern.log4j.Log4j;

@Log4j
public class ProductImgServiceImpl implements ProductImgService {

	private ProductImgMapper productImgMapper;
		
	@Override
	public List<ProductImgVO> list(String pid) {
		log.info("imglist.....");
		
		return productImgMapper.selectAll(pid);
	}

	@Override
	public boolean add(ProductImgVO pivo) {
		log.info("img add.....");
		
		return productImgMapper.insert(pivo)==1;
	}

	@Override
	public boolean remove(String uuid) {
		log.info("img remove.....");
		return productImgMapper.delete(uuid) ==1;
	}

}
