package org.zerock.service;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class SampleServiceTests {
	
	@Setter(onMethod_ = @Autowired)
	private SampleService sampleService;

	
	@Test
	public void testAround() throws Exception{
		log.info(sampleService.doAdd("300", "400"));
	}
	
	
	
	public void testAddError() throws Exception{
		log.info(sampleService.doAdd("200", "삼백"));
	}
	
	
	
	public void sampleParam() throws Exception {
		
		log.info(sampleService.doAdd("200", "300"));
		
	}
	
	

	public void sampleTest() {
		assertNotNull(sampleService);
		log.info(sampleService);    
		
		// INFO : org.zerock.service.SampleServiceTests - org.zerock.service.SampleServiceImpl@42b84286
		// sampleService 객체 만들어지는지
	}
	

	public void sampleTest2() throws Exception {
		
		log.info(sampleService.getClass().getName());
		
		// INFO : org.zerock.service.SampleServiceTests - com.sun.proxy.$Proxy32
		
		log.info(sampleService.doAdd("100", "200"));
		
		// INFO : org.zerock.aop.LogAdvice - -------------------   직접 호출하지는 않았지만 logAdvice에서 메서드가 실행되기 전에 호출
		// INFO : org.zerock.service.SampleServiceTests - 300
	}

}
