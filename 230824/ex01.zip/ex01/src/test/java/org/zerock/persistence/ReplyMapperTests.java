package org.zerock.persistence;


import java.util.stream.IntStream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.BoardVO;
import org.zerock.domain.Criteria;
import org.zerock.domain.ReplyVO;
import org.zerock.mapper.ReplyMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ReplyMapperTests {
	
	@Setter(onMethod_ = @Autowired)
	private ReplyMapper replyMapper;
	
	// 실재하는 게시물의 bno 저장
	private int[] bnoArr = { 50, 51, 52, 53, 54 };
	
	@Test
	public void selectPagingTest() {	
		Criteria cri = new Criteria();
		
		log.info("---------------------------");
		replyMapper.reSelectAllPaging(50,cri).forEach(bvo -> log.info(bvo));
		log.info("---------------------------");
	
		
	}
	
	
	public void testInsert() {							// insert
		// bnoArr 배열의 게시물에 각 2개씩 댓글 등록
		IntStream.rangeClosed(1, 10)   // insert 10번
				 .forEach(i -> {		// 람다식으로 forEach
					 ReplyVO rvo = new ReplyVO();	// ReplyVO 객체 생성
					 rvo.setBno(bnoArr[i % 5]);
					 rvo.setReply("댓글 테스트" + i);
					 rvo.setReplyer("replyer" + i);
					 replyMapper.reInsert(rvo);
				 });						
		
	}
	
	
	public void testSelect() {
		log.info("---------------------------");
		replyMapper.reSelect(1);									// 하나 가져오는건 매개변수 사용
		log.info("---------------------------");
		
	}
	
	
	public void update() {							 // update
		
		ReplyVO rvo = new ReplyVO();				// BoardVO 객체 생성
		 
		rvo.setRno(1);
		rvo.setReply("hello");
		
		log.info("update count : " +replyMapper.reUpdate(rvo));  // 로 확인 가능 이렇게하면 업데이는 되는 개수
		 														// mapper에서 int로 return맞춰놓음
		
	}
		
	
	public void delete() {							// delete
		
		replyMapper.reDelete(1); 
		// log.info("delete count : " + boardMapper.delete(1)); 로 확인 가능
		
	}

}
