package org.zerock.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.zerock.domain.Criteria;
import org.zerock.domain.ReplyVO;

public interface ReplyMapper {
	
	// insert  여기서 boolean으로 true,false로 해도 되고
		public int reInsert(ReplyVO rvo);
	
		//  rno로 하나 가져오기
		public ReplyVO reSelect(int rno);
		
		
		// delete
		public int reDelete(int rno);
		
		// update
		public int reUpdate(ReplyVO rvo);
		
		// 전체 목록 페이징
		public List<ReplyVO> reSelectAllPaging(@Param("bno") int bno,
											@Param("cri") Criteria cri);
		// 파라미터 두개이상 보내면 param 붙여서 보내야함.
		// 파람은 myBatis에서만 사용 service에서는 사용하지 않는다.
}
