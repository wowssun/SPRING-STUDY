package org.zerock.service;

import java.util.List;

import org.zerock.domain.Criteria;
import org.zerock.domain.ReplyVO;

public interface ReplyService {
	
	
	// 전체 목록 페이징
	public List<ReplyVO> list(int bno, Criteria cri);

	// rno로 하나 조회하기
	public ReplyVO view(int rno);
	
	// insert  댓글 등록
	public boolean add(ReplyVO rvo);
	
	// 일단 여기는 boolean으로 해놓고 insertSelectKey 사용했는데
	// 다시 해봐야함.
	
	// delete
	public boolean remove(int rno);
	
	// update
	public boolean modify(ReplyVO rvo);
	
			
	
	
}
