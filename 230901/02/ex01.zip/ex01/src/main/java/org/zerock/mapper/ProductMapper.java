package org.zerock.mapper;

import java.util.List;

import org.zerock.domain.ProductVO;

public interface ProductMapper {
	
	
	// 상품 전체 목록 
	public List<ProductVO> proSelectAll();
	
	// 상품 조회
	public ProductVO proSelect(String pid);
	
	// 상품 등록
	public int proInsert(ProductVO pvo);
	
	// 상품 수정
	public int proUpdate(ProductVO pvo);
	
	// 상품 삭제
	public int proDelete(String pid);
	
	
	
	
	

}
