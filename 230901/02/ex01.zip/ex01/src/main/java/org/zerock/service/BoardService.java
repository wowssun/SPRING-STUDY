package org.zerock.service;

import java.util.List;

import org.zerock.domain.BoardAttachVO;
import org.zerock.domain.BoardVO;
import org.zerock.domain.Criteria;

public interface BoardService {

	// service단은 사용자쪽에 더 가까워서 메서드 이름을 이렇게 변경해준다.
	
	
		// 전체 가져오기
		public List<BoardVO> list();
		
		// bno로 하나 가져오기
		public BoardVO view(int bno);
		
		// insert  여기서 boolean으로 true,false로 해도 되고 
		public boolean register(BoardVO bvo);
		
		// 시퀀스 하나 미리 저장해놓고 ,insert  여기서 boolean으로 true,false로 해도 되고 
		public int insertSelectKey(BoardVO bvo);
		
		// delete
		public boolean remove(int bno);
		
		// update
		public boolean modify(BoardVO bvo);
		
		// 첨부파일 전체 가져오기
		public List<BoardAttachVO> attachList(int bno);
		
		
		// 댓글 수 업데이트
		// public boolean replyCntmodify(int amount, int bno);
		
		
		// 전체 게시물 수
		public int totalCount(Criteria cri);
		
		// 전체 목록 페이징
		public List<BoardVO> list(Criteria cri);
}
