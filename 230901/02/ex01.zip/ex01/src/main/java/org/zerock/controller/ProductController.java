package org.zerock.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.zerock.domain.ProductVO;
import org.zerock.service.ProductService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/product/*")
@AllArgsConstructor
public class ProductController {
	
	private ProductService productService;

	// 상품 전체 목록
	@GetMapping("list")
	public void list(Model model) {
			
	log.info("pro controller list.....");
	
	model.addAttribute("list", productService.list());
		
	}
	
	
	// 상품 조회
	@GetMapping({"view" , "modify"})
	public void view(String pid, Model model) {
		log.info(" pro controller view or modify...");
		
		model.addAttribute("pvo", productService.view(pid));
	}		
	
	// 상품 등록 ( 화면 )
	@GetMapping("register")
	public void register() {
		
		log.info("pro controller register.....");
	}
	
	// 상품 등록( 폼 submit)
	@PostMapping("register")
	public String register(ProductVO pvo, RedirectAttributes rttr) {
		
		productService.register(pvo);
		
		rttr.addAttribute("result", pvo.getPid());
				
		return "redirect:/product/list";
	}
	
	// 상품 수정
	@PostMapping("modify")
	public String modify(ProductVO pvo, RedirectAttributes rttr) {
		log.info("pro controller modify.....");
		
		productService.modify(pvo);
		
		rttr.addAttribute("result", "modify success");
		
		
		return "redirect:/product/list";
	}
	
	
	// 상품 삭제
	@PostMapping("remove")
	public String remove(String pid, RedirectAttributes rttr) {
		log.info("pro controller remove....");
		
		productService.remove(pid);
		
		// 성공시
		rttr.addAttribute("result","remove success");
		
		
		return "redirect:/product/list";
	}
	
	
}
