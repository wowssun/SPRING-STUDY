CREATE TABLE tbl_attach (
    bno NUMBER CONSTRAINT fk_board_attach REFERENCES tb1_board(bno),
    uuid VARChaR2(100) CONSTRAINT pk_attach PRIMARY KEY,
    upFolder Varchar2(200) not null,
    fileName varchar2(100) not null,
    image char(1));

select * from tbl_attach;

SELECT * FROM tbl_attach WHERE bno =13;

CREATE TABLE tbl_reply (
    rno     NUMBER  CONSTRAINT pk_reply PRIMARY KEY,
    bno     NUMBER  CONSTRAINT fk_reply REFERENCES tb1_board(bno) NOT NULL,
    reply   VARCHAR2(1000) NOT NULL,
    replyer VARCHAR2(50)   NOT NULL,
    regDate     DATE    DEFAULT SYSDATE,
    updateDate  DATE    DEFAULT SYSDATE
);

CREATE INDEX idx_reply ON tbl_reply(bno DESC, rno ASC);

 /*+INDEX_DESC(tbl_reply bno) */

 /*+INDEX_DESC(tb1_board pk_board) */

 CREATE INDEX idx_board ON tb1_board(bno DESC);
 
 
CREATE SEQUENCE seq_reply NOCACHE;

CREATE TABLE tb1_board (
    bno number constraint pk_board primary key,
    title varchar2(200) not null,
    content varchar2(200) not null,
    writer varchar2(200) not null,
    regdate date default sysdate,
    updatedate date default sysdate );
    


ALTER TABLE tb1_board ADD replyCnt number;

UPDATE tb1_board SET replyCnt =(SELECT count(*) FROM tbl_reply where tbl_reply.bno=tb1_board.bno); 

UPDATE tb1_board SET replyCnt = replyCnt + 1 WHERE  bno = 8;

 
SELECT count(*) FROM tbl_reply where bno=50;

 
create sequence seq_board nocache;
 
 insert into tb1_board(bno,title, content, writer)
 values(seq_board.nextval, '테스트 제목', '테스트 내용', 'user00');
 
 select * from tb1_board;
 select * from tbl_reply;
 
 SELECT * FROM tb1_board ORDER BY bno DESC;


 SELECT  bno, title, content, writer, regDate, updateDate
    FROM ( SELECT /*+INDEX_DESC(tb1_board pk_board) */
    			rownum rn, bno, title, content, writer,
    			regDate, updateDate
    			FROM tb1_board
    			WHERE rownum <= 3 * 2)
  	WHERE rn > 3 * (2-1);
    
SELECT rno, bno, reply, replyer, regDate, updateDate
     FROM (SELECT /*+INDEX(tbl_reply idx_reply) */
        rownum rn,bno, rno, reply, replyer, regDate, updateDate
        FROM tbl_reply
        WHERE bno = 13 
        AND rownum <= 3 * 1)
        WHERE rn > 3 * (1-1);
 
SELECT COUNT(*) FROM tbl_reply WHERE bno=50;
 
CREATE TABLE tbl_sample1(coll varchar2(100));
CREATE TABLE tbl_sample2(coll varchar2(10));
 
INSERT INTO tbl_sample1 VALUES('하이루');

insert into tbl_attach values(88,'uuid','2023\08\31','파일이름',0);
insert into tbl_attach values(8, 'uiui','2023\08\31','파일네임',1);

select * from tbl_sample1;
select * from tbl_Sample2;


select * from tbl_attach
WHERE TO_DATE(upFolder, 'yyyy\MM\dd') >= TRUNC(SYSDATE) - 1
AND TO_DATE(upFolder, 'yyyy-MM-dd') < TRUNC(SYSDATE); 

select * from tbl_attach
WHERE upFolder= TO_CHAR(SYSDATE - 1, 'yyyy\MM\dd');

SELECT * from tbl_attach
		WHERE upFolder= TO_CHAR(SYSDATE - 1, 'yyyy\MM\dd'); 	

select * from tbl_attach;

insert into tbl_attach values(8, 'uiui','2023\08\31','파일네임.png',1);

DELETE FROM tbl_attach WHERE BNO=8;

 commit;
 