package market.filter;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;


@WebFilter("/*")  // 쇼핑몰 접근 로그기록
public class LogFilter extends HttpFilter implements Filter {
	private PrintWriter pw;
	private SimpleDateFormat dateTimeFmt;

	private static final long serialVersionUID = 1L;

	
	public void destroy() {
		// 로그 기록용 파일 닫기
		System.out.println("-- MARKET ACCESS LOFGGING END -- ");
		if(pw !=null) {
			pw.close();
		}
	}
		
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// 요청 URI 및 쿼리 스트링을 로그 기록 파일에 쓰기  pw.println(~~)
		pw.println("접속 시간 : " + getDateTime());    // 접속 시간 : ~~~
		pw.println("클라이언트 IP : " + request.getRemoteAddr() );// 클라이언트 IP : ~~~    요청객체, 리모트?
		pw.println("요청 URL : "   );// 요청 URL : ~~~ (요청 URI + 쿼리 스트링(있는 경우))
		
		chain.doFilter(request, response);
		
		pw.println("처리 완료 시간 : " + getDateTime());// 처리 완료 : ~~~ (시간)  get 데이트 ㅌ타임호출
		pw.println("소요 시간 : ");// 소요 시간 : ~~~      초단위로 시간빼기  위의 시간에서 아래의 시간
		// ----------------------
	}

	
	public void init(FilterConfig fConfig) throws ServletException {
		// 로그 기록용 파일 생성
		System.out.println("-- MARKET ACCESS LOFGGING START -- ");
		dateTimeFmt = new SimpleDateFormat("yyyy.MM.dd hh:mm:ss");   // jsp에서 만들었던 것을 자바에서 하는 방법
		
		String path = fConfig.getServletContext().getRealPath("/log/");   // 이 폴더에 로그를 쌓을거임
		String file = getDateTime().substring(0, 10) + ".log";
		System.out.println(path + file);
		
		try {			// append 모드로 파일 객체생성
			FileWriter fw = new FileWriter(path + file, true);
			pw = new PrintWriter(fw, true);  // auto flush mode
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public String getDateTime() {
		return dateTimeFmt.format(new Date());
	}

}
