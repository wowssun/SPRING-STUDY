package market.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import market.util.DBConn;
import market.vo.MemberVO;

public class MemberDAO {
	private Connection con;
	private String query; // 쿼리문 저장 필드
	private PreparedStatement psmt;
	private ResultSet rs;
	
	public Connection getCon() {
		return con;
	}

	public void setCon(Connection con) {
		this.con = con;
	}
	
	
	// 회원 인증
	public boolean isMember(String id, String pw){
		try {
			query = "SELECT COUNT (*) FROM member WHERE ID = ? AND PW=?";// 로그인 하는 쿼리 작성
			psmt = DBConn.getConnection().prepareStatement(query);
			
			psmt.setString(1,id);
			psmt.setString(2,pw);
				
			rs = psmt.executeQuery();  // 매개변수로 넘겨받은 유효한 사용자인지 확인
			
			if(rs.next()) {  // 조회된 레코드가 있다면
					if(rs.getInt(1)==1) { // COUNT로 사용했으니 1이 넘겨오면 사용자가 있다. -> 로그인 가능
						return true;	  // COUNT 로 0 이 넘어오면 사용자 존재 안함 -> 로그인 불가 메시지
				}
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}finally { 
		 DBConn.close(rs, psmt); // 사용한 코드가 rs와 psmt다. 이 두개를 닫기
		}	
			return false;		
	}
	
	
	// 회원 등록
	public boolean insert(MemberVO mvo) {
		try { // 쿼리를 실행하다가 예외가 발생할 수 있으니까 try/ catch문에다가 // insert 쿼리문
			query = " INSERT INTO member VALUES (?, ?, ?, ?, ?, ?, SYSDATE)"; // 이미지가 null이면 default 이미지를
																							// 넣고 아니면 선택 이미지 넣기

			// 매개변수로 넘겨받은 데이터를 product 테이블에 저장
			psmt = DBConn.getConnection().prepareStatement(query);
			//psmt = con.prepareStatement(query);

			psmt.setString(1, mvo.getId());
			psmt.setString(2, mvo.getPw());
			psmt.setString(3, mvo.getName());
			psmt.setString(4, mvo.getPhone());
			psmt.setString(5, mvo.getEmail());
			psmt.setString(6, mvo.getPhoto());
		    

			int result = psmt.executeUpdate();

			if (result == 1) { // 정상적으로 회원가입 성공 시 true 반환
				return true;
				// 여기서 메시지를 보낸다. logoutProc를 참고
				// session에 저장?
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(psmt);
		}

		// 그렇지 않으면 false 반환
		return false;   // 여기서 메시지를 보낸다.

	} // insert end
	
}
