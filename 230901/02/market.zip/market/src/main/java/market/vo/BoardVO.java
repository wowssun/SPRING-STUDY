package market.vo;

import java.util.Date;

public class BoardVO {

	private int num;				// 게시글 번호 , 시퀀스
	private String id;        		// 작성자
	private String subject;			// 제목
	private String content;			// 내용
	private Date regDate;			// 등록일
	private int hit;				// 조회수
	private String ip;				// 사용자 ip
	
	
	public BoardVO() {
	
	}


	public int getNum() {
		return num;
	}


	public void setNum(int num) {
		this.num = num;
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getSubject() {
		return subject;
	}


	public void setSubject(String subject) {
		this.subject = subject;
	}


	public Date getRegDate() {
		return regDate;
	}


	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}


	public int getHit() {
		return hit;
	}


	public void setHit(int hit) {
		this.hit = hit;
	}


	public String getIp() {
		return ip;
	}


	public void setIp(String ip) {
		this.ip = ip;
	}


	public String getContent() {
		return content;
	}


	public void setContent(String content) {
		this.content = content;
	}
	

	
}
