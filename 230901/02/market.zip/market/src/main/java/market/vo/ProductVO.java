package market.vo;

import java.io.Serializable;

public class ProductVO implements Serializable {
	private static final long serialVersionUID = 1L; 
	
	private String pid;						// 제품 코드
	private String pname; 					// 제품 이름
	private int  price;						// 제품 가격
	private String description;				// 설명
	private String maker;					// 제조사
	private String category;				// 분류
	private int stock;						// 재고 수량
	private String condition;				// 신상품 | 중고품 | 재생품
	private String pimage;					// 이미지 파일명
	private int quantity;					// 장바구니에 담은 수량
	
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getMaker() {
		return maker;
	}
	public void setMaker(String maker) {
		this.maker = maker;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	public String getPimage() {
		return pimage;
	}
	public void setPimage(String pimage) {
		this.pimage = pimage;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	

}
