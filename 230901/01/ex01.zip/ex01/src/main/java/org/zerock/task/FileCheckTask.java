package org.zerock.task;



import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.zerock.domain.BoardAttachVO;
import org.zerock.mapper.BoardAttachMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Component
@Log4j
public class FileCheckTask {
	
	@Setter(onMethod_ = @Autowired)
	private BoardAttachMapper boardAttachMapper;
	
	public String getYesterdatFolder() {  			// 1. 어제 날짜 폴더 문자열 반환
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");    // SimpleDateFormat으로 날짜 패턴지정
		Calendar cal = Calendar.getInstance();									// 여기 다시한번 공부하기 
		cal.add(Calendar.DATE, -1);
		
		String str = dateFormat.format(cal.getTime());				// 지정한 패턴으로 변경

		return str.replace("-",File.separator);
	}
		
	
	@Scheduled(cron = "0 0 9 * * *")			// 2. 매일 아침 9시 실행 설정
	public void checkFiles() throws Exception{		
		
			
		try {
			Date now =new Date();
			log.warn("Running.... : " +now.toLocaleString());    // log.info로 했더니 안됨. 그래서 log.warn으로
			log.warn("-------------------------------------------");
			
			// 첨부파일 테이블에서 어제 날짜의 첨부파일 목록 가져오기
			List<BoardAttachVO> yesterdayFiles = boardAttachMapper.yesterdayFiles();
			
			// Path가 들어있는 목록
			List<Path> fileList = yesterdayFiles.stream().map(bavo -> Paths.get("c:\\upload\\" + bavo.getUpFolder()+ "\\"
																							   + bavo.getUuid()+ "_"
																							   + bavo.getFileName()))
																						.collect(Collectors.toList());
			
			
			yesterdayFiles.stream().filter(bavo -> bavo.isImage() == true).map(bavo -> Paths.get("c:\\upload\\" + bavo.getUpFolder() + "\\s_"
																							  + bavo.getUuid() + "_"
																							  + bavo.getFileName()))
																						.forEach(path ->fileList.add(path));
																							 
			
			File target = Paths.get("c:\\upload\\" + getYesterdatFolder()).toFile();
			
			File[] removeFiles = target.listFiles(file -> fileList.contains(file.toPath())== false);

			log.warn("fileList : " + fileList);
			log.warn("target : " + target.toString());
			log.warn("removeFiles : " + Arrays.toString(removeFiles));
					
			for(File f :removeFiles) {
				f.delete();
			}
			
		}catch(Exception e) {
			log.warn("에러내용 :" + e);
		}
	}
	
	

}
