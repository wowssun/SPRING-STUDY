package org.zerock.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.Criteria;
import org.zerock.domain.ReviewVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ReviewServiceTests {
	
	@Setter(onMethod_ =@Autowired )
	private ReviewService reviewService;
	
	
	// 하나 조회
	public void testView() {   // 성공
		log.info(reviewService.view(3));
		
	}
	
	// 등록
	public void testRegister() {   // 성공
		
		ReviewVO revvo = new ReviewVO();
		
		revvo.setPid("P1241");					
		revvo.setReview("new reply");				
		revvo.setReviewer("new replyer");
		 
		reviewService.add(revvo);					
		 
 		log.info("생성된 댓글 번호 :" + revvo.getRevno());	
		
		
	}
		
	// 삭제 // 성공
	public void testRemove() {  // 그럼 결과값이 true로 뜰 것이다. boolean으로 되어 있어서
		log.info("delete count :" + reviewService.remove(2));
		
	}
	


}
