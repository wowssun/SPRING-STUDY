package org.zerock.service;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.BoardAttachVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BoardAttachServiceTests {

	@Setter(onMethod_ = @Autowired )
	private BoardAttachService boardAttachService;
	
	// 테스트 안해봄~~~~~

	public void testRegister() {
			
		BoardAttachVO bavo = new BoardAttachVO();
			
		bavo.setBno(13);					
		
			boardAttachService.add(bavo);					// 여기서는 boardServie에 있는거 불러오기 register
			 
	 	//	log.info("생성된 댓글 번호 :" + bavo.getRno());	
			
			
		}
	
	public void testRemove() {  // 그럼 결과값이 true로 뜰 것이다. boolean으로 되어 있어서
		log.info("delete count :" + boardAttachService.remove("uuid"));
		
	}	
	
	// 전체목록 테스트
	public void testList() {
		log.info("---------------------");
		boardAttachService.list(13).forEach(bvo -> log.info(bvo));	
		log.info("---------------------");
		
		
	}
	
	
	
	
} 
