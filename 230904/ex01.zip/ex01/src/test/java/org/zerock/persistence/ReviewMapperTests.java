package org.zerock.persistence;

import org.apache.ibatis.annotations.Select;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.mapper.ReviewMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ReviewMapperTests {
	
	@Setter(onMethod_ = @Autowired )
	private ReviewMapper reviewMapper;
	
	
	public void testSelect() {  // 성공
		log.info("---------------------------");
		reviewMapper.reviewSelect(1);									// 하나 가져오는건 매개변수 사용
		log.info("---------------------------");
		
	}
	
	@Test
	public void delete() {		 // 성공					// delete
		
		reviewMapper.reviewDelete(1); 
		// log.info("delete count : " + boardMapper.delete(1)); 로 확인 가능
		
	}
	
	

}
