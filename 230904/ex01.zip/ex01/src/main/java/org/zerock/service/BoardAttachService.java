package org.zerock.service;

import java.util.List;

import org.zerock.domain.BoardAttachVO;


public interface BoardAttachService {
	
	
			// 전체 가져오기
			public List<BoardAttachVO> list(int bno);
		
			// insert   
			public boolean add(BoardAttachVO bavo);
			
			// delete
			public boolean remove(String uuid);


}
