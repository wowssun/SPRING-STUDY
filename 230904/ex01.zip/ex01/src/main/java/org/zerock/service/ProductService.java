package org.zerock.service;

import java.util.List;

import org.zerock.domain.ProductVO;

public interface ProductService {

	
		// 상품 전체 목록 
		public List<ProductVO> list();
		
		// 상품 조회
		public ProductVO view(String pid);
		
		// 상품 등록
		public boolean register(ProductVO pvo);
		
		// 상품 수정
		public boolean modify(ProductVO pvo);
		
		// 상품 삭제
		public boolean remove(String pid);
	
	
	
	
	
}
