package org.zerock.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.zerock.domain.Criteria;
import org.zerock.domain.ReviewPageDTO;
import org.zerock.domain.ReviewVO;
import org.zerock.mapper.ProductMapper;
import org.zerock.mapper.ReviewMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Service
@AllArgsConstructor
@Log4j
public class ReviewServiceImpl implements ReviewService {
	
	private ProductMapper productMapper;
	private ReviewMapper reviewMapper;
	

	@Transactional   // 트랜잭션 어노테이션 필수 -> 등록되면 리뷰 카운트+1
	@Override
	public boolean add(ReviewVO revo) {
		log.info("review add.....");
		
		productMapper.updateReviewCnt(1, revo.getPid());
		return reviewMapper.reviewInsert(revo)==1;
	}

	@Override
	public ReviewVO view(int revno) {
		log.info("review view...");
		return reviewMapper.reviewSelect(revno);
	}

	@Override
	public boolean remove(int revno) {
		ReviewVO revvo = reviewMapper.reviewSelect(revno);
		log.info("review remove");
		
		productMapper.updateReviewCnt(-1, revvo.getPid());
				
		return reviewMapper.reviewDelete(revno)==1;
	}

	@Override
	public boolean removeAll(String pid) {
	
		return false;
	}

	@Override
	public boolean modify(ReviewVO revno) {
		log.info("Review modify");
		
		return reviewMapper.reviewUpdate(revno)==1;
	}

	@Override
	public ReviewPageDTO list(String pid, Criteria cri) {
		
		// dto에 생성자를 만들었으니 dto에 두개를 담아서 보내면 된다.
		return new ReviewPageDTO(reviewMapper.selectReview(pid),
				reviewMapper.reviewSelectAllPaging(pid, cri));
	}

}
