package org.artauc.domain;

import lombok.Data;

@Data
public class FreeAttachVO {

	private int frno;
	private String uuid;
	private String upfolder;
	private String filename;
	private boolean image;
	
}
