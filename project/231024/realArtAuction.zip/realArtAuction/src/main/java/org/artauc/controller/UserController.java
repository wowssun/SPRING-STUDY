package org.artauc.controller;

import org.artauc.domain.ArtistVO;
import org.artauc.domain.MemberVO;
import org.artauc.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/user/*")
@Log4j
public class UserController {
	
	@Setter(onMethod_ = @Autowired )
	private UserService us;
	
	
	// 마이페이지 userMypage.jsp
	@GetMapping("mypage")
     public void mypage(String mid){ 
		
	}
	
	// 내 정보 보기 , 수정  myInfo.jsp myInfoModify.jsp
	
	@GetMapping({"myinfo" , "modify"})
	public void myinfo (String mid ,Model model) {
		
		// 여기서 로그인한 아이디가 들어가야함.
		// 일단 레이아웃만 테스트하고 나중에 변경하기
		// 그럼 security로 아이디를 넣어서 처리?
		log.info("myinfo..");
		
		model.addAttribute("mvo", us.view("abc"));	
	}
	
	 @PostMapping("modify") 
     public String modify(MemberVO mvo, RedirectAttributes rttr) {
		 
		 return "redirect:/user/myinfo" ;
	 }
	 
	 // 회원 탈퇴
	 @PostMapping("remove")
	 public String remove(String mid, RedirectAttributes rttr) {
		 
		 return "redirect:/artauction/main" ;
	 }
	 
	 // 작가 신청 artistReq.jsp
	 
	 @GetMapping("request")
	 public void request () {
		 
	 }
	 
	 
	 @PostMapping("request") 
	 public String request (ArtistVO avo, RedirectAttributes rttr) {
		 
		 return "redirect:/user/mypage" ;
	 }
	 
	 // 작가 신청 조회 하기 artistReqInfo.jsp
	 
	 @GetMapping("rqcheck")
	 public void rqcheck () {
		 
	 }
	 
	 @PostMapping("rqcheck") 
	 public void rqcheck  (String mid, Model model) {
		 
	 }
	 
	// - get /user/mypage  public void mypage  (String mid)  // 마이페이지 view // 작가 마이페이지 view artistrMypage.jsp
	 
	 // 작가 정보 보기 , 수정  artistInfo.jsp artistInfoModify.jsp
	 
	 @GetMapping({"artview" , "artmodify"})
	 public void artview  (String mid ,Model model) {
		 
	 }
	 
	 // 작가 정보 수정
	 
	 @PostMapping("artmodify") 
	 public String artmodify  (ArtistVO avo, RedirectAttributes rttr) {
		 
		 return "redirect:/user/artview" ;
	 }
	

	
	
	
}
