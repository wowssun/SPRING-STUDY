package org.artauc.controller;

import org.artauc.domain.Criteria;
import org.artauc.domain.RequestVO;
import org.artauc.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.artauc.domain.PageDTO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/admin/*")
@Log4j
public class AdminController {
	
	@Setter(onMethod_ = @Autowired )
	private AdminService as;
	
	// 관리자 메뉴 adminPage.jsp
	
	@GetMapping("adminPage")
	public void mypage  (String mid) {
		log.info("adminPage");
	}
	
	// 회원목록 userList.jsp
	
	@GetMapping("userList")
	public void userlist (Model model, Criteria cri) {
		log.info("userList..." + cri);
		
		model.addAttribute("list", as.list(cri));
		
		model.addAttribute("pageDTO", new PageDTO(cri,as.mtotalCount(cri)));
		
		model.addAttribute("count",as.mtotalCount(cri));
	}
	
	// 잠금회원목록 userLockList.jsp
	
	@GetMapping("userLockList")
	public void locklist(Model model, Criteria cri) {
		log.info("userLockList.." + cri);
		
		model.addAttribute("list", as.lockList(cri));
		
		model.addAttribute("pageDTO", new PageDTO(cri,as.locktotalCount(cri)));
		
		model.addAttribute("count",as.locktotalCount(cri));
		
	}
	
	// 잠금해제하기
	
	@PostMapping(value ="unlock", produces = "text/plain")
	@ResponseBody
	public String unlock(String mid) {
		log.info("unlock" + mid);
		
		String result;
		
		if(as.lockModify(mid)) {
			result = "true";
		}else {
			result = "false";
		}
		 		
		return result;
	}
	
	// 작가회원목록 artistList.jsp
	
	@GetMapping("artistList")
	public void artuserlist(Model model, Criteria cri) {
		log.info("artistList");
	}
	
	// 작가신청목록 artistReqList.jsp
	
	@GetMapping("rqList")
	public void rqlist (Model model, Criteria cri) {
		log.info("rqList.." + cri);
		
		model.addAttribute("list", as.requeList(cri));
		
		model.addAttribute("pageDTO", new PageDTO(cri,as.rtotalCount(cri)));
		
		model.addAttribute("count",as.rtotalCount(cri));
		
	}
	
	// artistReqView.jsp
	//- get /admin/rqview     public void rqview (String mid ,Model model, @ModelAttribute("cri") Criteria cri)   // 작가 신청상세조회 view select
	
	// 작가 신청 승인 거절
	/*  
	POST(작가 승인 / 거절 )	
	/admin/rqview
	/admin/approval   작가 승인
	/admin/refuse  작가 거절   */
	
	
	@PostMapping("state")
	 public String state (RequestVO rvo, RedirectAttributes rttr,@ModelAttribute("cri") Criteria cri) {
		log.info("state");
		
		return "redirect:/admin/rqlist" ; 
	}
	
	
	// 작가 승인 / 거절 목록 checkList.jsp
	
	@GetMapping("checkList")
	public void checklist   (Model model, Criteria cri) {
		log.info("checkList.." + cri);
		
		model.addAttribute("list", as.okNoList(cri));
		
		model.addAttribute("pageDTO", new PageDTO(cri,as.oknototalCount(cri)));
		
		model.addAttribute("count",as.oknototalCount(cri));
		
	}
	


	
	
	
	
}
