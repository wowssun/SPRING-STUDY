package domain;

import java.sql.Date;

import lombok.Data;

@Data
public class BidVO {

	private int ano;
	private String mid;
	private Date startDate;
	private Date endDate;
	private Date payDate;
	private int bidprice;
	private int cprice;
	private String condition;
	private boolean payStatement;
}
