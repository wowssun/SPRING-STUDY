package domain;

import java.sql.Date;

import lombok.Data;

@Data
public class PayVO {

	private int pno;
	private String mid;
	private String cardCO;
	private String cardNum;
	private int price;
	private Date payDate;
}
