package mapper;

import domain.PayVO;

public interface PayMapper {

	public PayVO select(String id);
		
}
