package service;

import domain.BidVO;

public interface BidService {

	public BidVO bidlist(String id, String condition);
	public BidVO sbidlist(String id, String condition);
}
