package service;

import java.util.List;

import domain.AucVO;
import domain.Criteria;

public class AucServiceImpl implements AucService {

	@Override
	public List<AucVO> selectAllPaging(Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean totalCount(Criteria cri) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(AucVO avo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(int ano) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean insertSelectKey(AucVO avo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public AucVO select(int ano) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateBid(int ano, String id, int cprice) {
		// TODO Auto-generated method stub
		return false;
	}

}
