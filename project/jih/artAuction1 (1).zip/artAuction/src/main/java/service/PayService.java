package service;

import domain.PayVO;

public interface PayService {

	public PayVO select(String id);
}
