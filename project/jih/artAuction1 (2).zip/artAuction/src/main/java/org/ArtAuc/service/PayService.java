package org.ArtAuc.service;

import org.ArtAuc.domain.PayVO;

public interface PayService {

	public PayVO select(String id);
}
