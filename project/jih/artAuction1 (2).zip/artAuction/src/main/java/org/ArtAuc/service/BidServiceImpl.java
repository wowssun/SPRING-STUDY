package org.ArtAuc.service;

import org.ArtAuc.domain.BidVO;
import org.ArtAuc.mapper.AucMapper;
import org.ArtAuc.mapper.BidMapper;
import org.springframework.beans.factory.annotation.Autowired;

import lombok.Setter;

public class BidServiceImpl implements BidService {
	@Setter(onMethod_ = @Autowired)
	private BidMapper bidMapper;

	@Override
	public BidVO bidlist(String id, String condition) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BidVO sbidlist(String id, String condition) {
		// TODO Auto-generated method stub
		return null;
	}

}
