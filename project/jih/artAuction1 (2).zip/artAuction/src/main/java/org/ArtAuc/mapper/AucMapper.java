package org.ArtAuc.mapper;

import java.util.List;

import org.ArtAuc.domain.AucVO;
import org.ArtAuc.domain.Criteria;

public interface AucMapper {

	public List<AucVO> selectAllPaging(Criteria cri);
	public int totalCount(Criteria cri);
	public int update(AucVO avo);
	public int delete(int ano);
	public int insertSelectKey(AucVO avo);
	public AucVO select(int ano);
	public int updateBid(int ano, String id, int cprice);
	
}
