package org.ArtAuc.mapper;

import org.ArtAuc.domain.PayVO;

public interface PayMapper {

	public PayVO select(String id);
		
}
