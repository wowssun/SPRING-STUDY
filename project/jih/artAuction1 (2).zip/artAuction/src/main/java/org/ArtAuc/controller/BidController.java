package org.ArtAuc.controller;

import org.ArtAuc.domain.Criteria;
import org.ArtAuc.service.BidService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/bid/*")
@AllArgsConstructor
public class BidController {
	private BidService bidService;

	@GetMapping("bidlist")
	public void mybidlist(Model model, Criteria cri, String mid, String condition) {

	}
	
	@GetMapping("sbidlist")
	public void mysbidlist(Model model, Criteria cri, String mid, String condition) {

	}
	
}
