package org.ArtAuc.service;

import org.ArtAuc.domain.PayVO;
import org.ArtAuc.mapper.AucMapper;
import org.ArtAuc.mapper.PayMapper;
import org.springframework.beans.factory.annotation.Autowired;

import lombok.Setter;

public class PayServiceImpl implements PayService {
	@Setter(onMethod_ = @Autowired)
	private PayMapper payMapper;

	@Override
	public PayVO select(String id) {
		// TODO Auto-generated method stub
		return null;
	}

}
