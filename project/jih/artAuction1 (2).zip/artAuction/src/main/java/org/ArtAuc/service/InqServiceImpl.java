package org.ArtAuc.service;

import java.util.List;

import org.ArtAuc.domain.Criteria;
import org.ArtAuc.domain.InqVO;
import org.ArtAuc.mapper.AucMapper;
import org.ArtAuc.mapper.InqMapper;
import org.springframework.beans.factory.annotation.Autowired;

import lombok.Setter;

public class InqServiceImpl implements InqService {
	@Setter(onMethod_ = @Autowired)
	private InqMapper inqMapper;

	@Override
	public List<InqVO> selectAllPaging(Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean totalCount(Criteria cri) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(InqVO ivo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(int rno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean insertSelectKey(InqVO ivo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public InqVO select(int rno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean add(int rno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean ansupdate(int rno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean ansdelete(int rno) {
		// TODO Auto-generated method stub
		return false;
	}

}
