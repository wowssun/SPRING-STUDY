package org.ArtAuc.service;

import java.util.List;

import org.ArtAuc.domain.AucVO;
import org.ArtAuc.domain.Criteria;
import org.ArtAuc.mapper.AucMapper;
import org.springframework.beans.factory.annotation.Autowired;

import lombok.Setter;

public class AucServiceImpl implements AucService {
	@Setter(onMethod_ = @Autowired)
	private AucMapper aucMapper;
	
	@Override
	public List<AucVO> selectAllPaging(Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean totalCount(Criteria cri) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(AucVO avo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(int ano) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean insertSelectKey(AucVO avo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public AucVO select(int ano) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateBid(int ano, String id, int cprice) {
		// TODO Auto-generated method stub
		return false;
	}

}
