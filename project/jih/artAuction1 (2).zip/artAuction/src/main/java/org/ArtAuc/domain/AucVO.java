package org.ArtAuc.domain;

import java.sql.Date;

import lombok.Data;

@Data
public class AucVO {

	private int ano;
	private String mid;
	private String artname;
	private String artist;
	private Date startDate;
	private Date endDate;
	private int Cprice;
	private int Eprice;
	private String intro;
	private String art_img;
}
