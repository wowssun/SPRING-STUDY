package org.ArtAuc.mapper;

import java.util.List;

import org.ArtAuc.domain.Criteria;
import org.ArtAuc.domain.InqVO;

public interface InqMapper {

	public List<InqVO> selectAllPaging(Criteria cri);
	public int totalCount(Criteria cri);
	public int update(InqVO ivo);
	public int delete(int rno);
	public int insertSelectKey(InqVO ivo);
	public InqVO select(int rno);
	public int add(int rno);
	public int ansupdate(int rno);
	public int ansdelete(int rno);
	
	
}
