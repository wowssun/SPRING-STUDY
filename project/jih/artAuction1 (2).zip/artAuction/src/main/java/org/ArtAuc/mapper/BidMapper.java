package org.ArtAuc.mapper;

import org.ArtAuc.domain.BidVO;

public interface BidMapper {

	public BidVO bidlist(String id, String condition);
	public BidVO sbidlist(String id, String condition);
		
}
