package Service;

import java.util.List;

import Domain.AucVO;
import Domain.Criteria;

public interface AucService {

	public List<AucVO> selectAllPaging(Criteria cri);
	public boolean totalCount(Criteria cri);
	public boolean update(AucVO avo);
	public boolean delete(int ano);
	public boolean insertSelectKey(AucVO avo);
	public AucVO select(int ano);
	public boolean updateBid(int ano, String id, int cprice);
	
}
