package Service;

import Domain.PayVO;

public class PayServiceImpl implements PayService {

	@Override
	public PayVO select(String id) {
		// TODO Auto-generated method stub
		return null;
	}

}
