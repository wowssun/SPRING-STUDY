package Service;

import java.util.List;

import Domain.Criteria;
import Domain.InqVO;

public class InqServiceImpl implements InqService {

	@Override
	public List<InqVO> selectAllPaging(Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean totalCount(Criteria cri) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(InqVO ivo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(int rno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean insertSelectKey(InqVO ivo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public InqVO select(int rno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean add(int rno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean ansupdate(int rno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean ansdelete(int rno) {
		// TODO Auto-generated method stub
		return false;
	}

}
