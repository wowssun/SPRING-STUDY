package Service;

import java.util.List;

import Domain.Criteria;
import Domain.InqVO;

public interface InqService {

	public List<InqVO> selectAllPaging(Criteria cri);
	public boolean totalCount(Criteria cri);
	public boolean update(InqVO ivo);
	public boolean delete(int rno);
	public boolean insertSelectKey(InqVO ivo);
	public InqVO select(int rno);
	public boolean add(int rno);
	public boolean ansupdate(int rno);
	public boolean ansdelete(int rno);
	
}
