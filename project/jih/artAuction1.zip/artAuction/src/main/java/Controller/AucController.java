package Controller;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import Domain.AucVO;
import Domain.Criteria;
import Domain.InqVO;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/auction/*")
@AllArgsConstructor
public class AucController {

	@GetMapping("list")
	public void list(Model model, Criteria cri) {

	}
	
	@GetMapping("mylist")
	public void mylist(Model model, Criteria cri, String id) {

	}

	@GetMapping("register")
	public void register() {
	}

	@PostMapping("register")
	public String register(AucVO avo, RedirectAttributes rttr) {

		return null;
	}

	@GetMapping({ "view", "modify" })
	public void view(int ano, Model model, @ModelAttribute("cri") Criteria cri) {

	}

	@PostMapping("modify")
	public String modify(AucVO avo, RedirectAttributes rttr, @ModelAttribute("cri") Criteria cri) {

		return null;
	}

	@PostMapping("remove")
	public String remove(int ano, RedirectAttributes rttr, @ModelAttribute("cri") Criteria cri) {

		return null;
	}

	// updateCurrentPrice �޼��� �߰�
	@PostMapping("updatebid")
	public String updateBid(int ano, String id, int cprice) {
		// ���簡�� ������ ������ ������Ʈ�ϴ� ������ �����մϴ�.

		return null;
	}

}
