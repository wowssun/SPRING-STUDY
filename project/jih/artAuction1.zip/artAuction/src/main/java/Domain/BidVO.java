package Domain;

import java.sql.Date;

import lombok.Data;

@Data
public class BidVO {

	private int ano;
	private String id;
	private Date startDate;
	private Date endDate;
	private int bidprice;
	private int cprice;
	private String condition;
	private boolean payStatement;
}
