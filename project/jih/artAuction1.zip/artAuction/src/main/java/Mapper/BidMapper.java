package Mapper;

import Domain.BidVO;

public interface BidMapper {

	public BidVO bidlist(String id, String condition);
	public BidVO sbidlist(String id, String condition);
		
}
