package Mapper;

import Domain.PayVO;

public interface PayMapper {

	public PayVO select(String id);
		
}
