package org.artauc.domain;

import lombok.Data;

@Data
public class ArtistVO {

	
	private String mid; // 아이디
	private String major; // 전공분야
	private String career; // 이력
	private String photo; // 첨부사진 —> 사진 처리할거 생각하기
	private String introduce; // 자기 소개
}
