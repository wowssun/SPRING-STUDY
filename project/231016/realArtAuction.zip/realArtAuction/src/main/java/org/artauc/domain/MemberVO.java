package org.artauc.domain;

import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class MemberVO {
	private String id;
	private String pw;
	private String name;
	private Date regDate;
	private Date updateDate;
	private boolean enabled;

	// role이 하나가 아닌 경우가 있기 때문에 list로 선언
	// 만약 단일 정보만 온다고 하면 vo만 가져왔다.
	private List<AuthVO> authList;
}
