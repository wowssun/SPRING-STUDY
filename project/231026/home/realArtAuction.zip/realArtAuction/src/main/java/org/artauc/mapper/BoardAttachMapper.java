package org.artauc.mapper;

import java.util.List;

import org.artauc.domain.BoardAttachVO;

public interface BoardAttachMapper {
	
		// 전체 가져오기
		public List<BoardAttachVO> selectAll(int bno);
		
		// insert  
		public int insert(BoardAttachVO bavo);
		
		// delete
		public int delete(String uuid);

		// deleteAll
		public int deleteAll(int bno);
		
		// 어제자 목록 가져오기
		public List<BoardAttachVO> yesterdayFiles();
}
