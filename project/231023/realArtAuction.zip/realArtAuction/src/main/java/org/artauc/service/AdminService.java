package org.artauc.service;

import java.util.List;

import org.artauc.domain.ArtistVO;
import org.artauc.domain.Criteria;
import org.artauc.domain.MemberVO;
import org.artauc.domain.RequestVO;

public interface AdminService {

	
	public List<MemberVO> list(Criteria cri); //회원목록 select MemberVO
	public List<MemberVO> lockList(Criteria cri); //잠금회원목록 select MemberVO
	public boolean lockModify(String mid); // 잠금해제하기 update
	// 미완
	public List<MemberVO> artList(Criteria cri); //작가회원목록 select MemberVO
	public List<RequestVO> requeList(Criteria cri); //작가신청목록 select RequestVO
	// 보류
	public ArtistVO requeselect(String mid); //작가 신청상세조회 select
	// 미완
	public boolean requeModify(String mid); //작가 신청 승인 / 거절 update
	// 미완
	public List<RequestVO> okNoList(Criteria cri); //작가 승인 / 거절 목록 select RequestVO
	public boolean remove(String mid) ;// 회원 탈퇴 delete
	
	// member 전체 게시물 수
    public int mtotalCount(Criteria cri);
    
	// artist 전체 게시물 수
    public int atotalCount(Criteria cri);
    
	// request 전체 게시물 수
    public int rtotalCount(Criteria cri);
}
