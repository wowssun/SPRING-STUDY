package org.artauc.controller;

import org.artauc.domain.Criteria;
import org.artauc.domain.RequestVO;
import org.artauc.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/admin/*")
@Log4j
public class AdminController {
	
	@Setter(onMethod_ = @Autowired )
	private AdminService as;
	
	// 관리자 메뉴 adminPage.jsp
	
	@GetMapping("mypage")
	public void mypage  (String mid) {
		
	}
	
	// 회원목록 userList.jsp
	
	@GetMapping("userlist")
	public void userlist (Model model, Criteria cri) {
		
	}
	
	// 잠금회원목록 userLockList.jsp
	
	@GetMapping("locklist")
	public void locklist(Model model, Criteria cri) {
		
	}
	
	// 잠금해제하기
	
	@PostMapping("unlock")
	public String unlock(RequestVO rvo, RedirectAttributes rttr) {
		
		return "redirect:/admin/locklist" ; 
	}
	
	// 작가회원목록 artistList.jsp
	
	@GetMapping("artuserlist")
	public void artuserlist(Model model, Criteria cri) {
		
	}
	
	// 작가신청목록 artistReqList.jsp
	
	@GetMapping("rqlist")
	public void rqlist (Model model, Criteria cri) {
		
	}
	
	// artistReqView.jsp
	//- get /admin/rqview     public void rqview (String mid ,Model model, @ModelAttribute("cri") Criteria cri)   // 작가 신청상세조회 view select
	
	// 작가 신청 승인 거절
	/*  
	POST(작가 승인 / 거절 )	
	/admin/rqview
	/admin/approval   작가 승인
	/admin/refuse  작가 거절   */
	
	
	@PostMapping("state")
	 public String state (RequestVO rvo, RedirectAttributes rttr,@ModelAttribute("cri") Criteria cri) {
	
		
		return "redirect:/admin/rqlist" ; 
	}
	
	
	// 작가 승인 / 거절 목록 artistCheckList.jsp
	
	@GetMapping("checklist")
	public void checklist   (Model model, Criteria cri) {
		
	}
	


	
	
	
	
}
