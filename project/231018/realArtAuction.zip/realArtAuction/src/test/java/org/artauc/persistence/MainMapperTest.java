package org.artauc.persistence;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.artauc.domain.MemberVO;
import org.artauc.mapper.MainMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class MainMapperTest {

	@Setter(onMethod_ = @Autowired )
	private MainMapper memMapper;
	
	
	@Test
	public void selectTest() {
		log.info("---------------------------");
		MemberVO mvo = memMapper.select("abc");
		log.info(mvo);
		log.info(mvo.getAuth().getMid());
		
		
		log.info("---------------------------");
		 mvo = memMapper.select("admin");
		log.info(mvo);
		log.info(mvo.getAuth().getAuth());
		
	}
}
