package org.artauc.service;

import org.artauc.domain.ArtistVO;
import org.artauc.domain.MemberVO;
import org.artauc.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service     												// 서비스단은 서비스 어노테이션
@Log4j
public class UserServiceImpl implements UserService {
	
	@Setter(onMethod_ = @Autowired)
	private UserMapper userMapper;

	@Override
	public MemberVO view(String mid) {
		
		log.info("view...");
		
		return userMapper.select(mid);
	}

	@Override
	public boolean modify(MemberVO mvo) {
		
		log.info("modify...");
		
		return userMapper.update(mvo)==1;
	}

	@Override
	public boolean remove(String mid) {
		
		log.info("remove...");
		
		return userMapper.delete(mid)==1;
	}

	@Override
	@Transactional 
	public boolean register(ArtistVO avo) {
		
		log.info("register...");
		
		if(userMapper.insert(avo)) {
			userMapper.reqInsert(avo.getMid());
			return true;
		}
			
		return false;
	}


	@Override
	public String artSearch(String mid) {
		
		log.info("artSearch...");
		
		return userMapper.artSearch(mid);
	}

	@Override
	public ArtistVO artView(String mid) {
		
		log.info("artView...");
		
		return userMapper.artSelect(mid);
	}

	@Override
	public boolean artModify(ArtistVO avo) {
		
		log.info("artModify...");
		
		return userMapper.artUpdate(avo)==1;
	}
	

	
	



}
