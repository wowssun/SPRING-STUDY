package org.artauc.persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.junit.Test;

import lombok.extern.log4j.Log4j;

@Log4j
public class JDBCTests {
	
	static {
		try {
			Class.forName("oracle.jdbc.OracleDriver"); // 드라이버 로딩	
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
}
	
	
	@Test
	public void estConnection () {
		try 
			(Connection con =  DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "dEv", "1111")){
																														
			log.info(con);
			System.out.println("con ok");
		} catch (Exception e) {	
			e.printStackTrace();
		}
		
	}
}
