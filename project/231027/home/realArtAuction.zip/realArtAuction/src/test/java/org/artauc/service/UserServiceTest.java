package org.artauc.service;

import org.artauc.domain.ArtistVO;
import org.artauc.domain.MemberVO;
import org.artauc.domain.RequestVO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class UserServiceTest {
	
	@Setter(onMethod_ = @Autowired)
	private UserService us;
	
	
	@Test
	public void viewTest() {
		log.info("---------------------------");
		us.view("abc");
		log.info("---------------------------");
		
	}
	
	
	
	public void modifyTest() {
		MemberVO mvo = new MemberVO();					
		 
		mvo.setPhone("change phone");
		mvo.setEmail("change email");
		mvo.setMid("new id");
		
		 log.info("update count : " + us.modify(mvo));  
		 														
		
	}
	
	
	public void removeTest() {
		log.info("delete count : " + us.remove("new id"));
	}
	
	
	
	public void registerTest() {
		ArtistVO avo = new ArtistVO();				
		//mid, major, introduce, career, photo) 
		avo.setMid("abc");					
		avo.setMajor("new major");				
		avo.setIntroduce("new introduce");
		avo.setCareer("-2023 career");
		avo.setPhoto("new photo");
		 
		us.register(avo);					
		 
		 log.info(avo);		
		
	}
	
	
	
	
	
	public void artSearchTest() {
		us.artSearch("abc");
	}
	
	
	public void artViewTest() {
		us.artView("abc");
	}
	
	
	public void artModifyTest() {
		ArtistVO avo = new ArtistVO();				
		//#{major}, introduce = #{introduce}, career = #{career}, photo = #{photo}
		avo.setMid("abc");					
		avo.setMajor("change major");				
		avo.setIntroduce("change introduce");
		avo.setCareer("-2023 chage career");
		avo.setPhoto("change photo");
		 
		;				
		 log.info("update conunt : " + us.artModify(avo));	
		 log.info(avo);		
		
	}
	

}
