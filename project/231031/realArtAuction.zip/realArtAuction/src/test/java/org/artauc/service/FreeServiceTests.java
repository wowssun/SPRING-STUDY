package org.artauc.service;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.artauc.domain.Criteria;


import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class FreeServiceTests {
	
	@Setter(onMethod_ = @Autowired )
	private FreeService fs;
	

	
	// 전체목록 페이징 테스트
	@Test
	public void testListPage() {
		
		Criteria cri = new Criteria();
		cri = new Criteria(3,2);
		
		log.info("---------------------");
		fs.selectMy("abc").forEach(fvo -> log.info(fvo));	
		log.info("---------------------");
		log.info("total count : " + fs.totalCount(cri));
		
	}
	
	
}
