package org.artauc.service;

import org.artauc.domain.ArtistVO;
import org.artauc.domain.MemberVO;

public interface UserService {

	
	public MemberVO view(String mid); //내 정보 보기 select MemberVO
	public boolean modify(MemberVO mvo); // 내 정보 수정 update
	public boolean remove(String mid) ;// 회원 탈퇴 delete
	public boolean register(ArtistVO avo); //작가신청 작가정보 insert
	public String artSearch(String mid); // 작가 신청 정보 조회 select
	public ArtistVO artView(String mid); //작가 정보 보기 select
	public boolean artModify(ArtistVO avo); // 작가 정보 수정 update
}
