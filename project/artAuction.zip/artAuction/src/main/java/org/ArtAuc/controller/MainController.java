package org.ArtAuc.controller;

import org.ArtAuc.domain.BoardVO;
import org.ArtAuc.domain.MemberVO;
import org.ArtAuc.service.MainService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@AllArgsConstructor
public class MainController {
	
	private MainService mainService;
	
	 public String logout () {
		return null;} // 로그아웃 security controller 참고
	 public String login (String error, String logout, Model model){
		return logout;} // 로그인 - security controller 참고
	 public void main (){}
	 public void join (){}// 회원가입 create
	 public String join (MemberVO mvo, RedirectAttributes rttr){
		return null;} // 회원가입 insert
	 public void idcheck(String mid) {} // 중복체크
	 public void idsearch (){} // 아이디 찾기
	 public void idsearch (String name, String phone, Model model ){} // 아이디 찾기
	 public void pwsearch () {}// 비밀번호 찾기
	 public void pwsearch (String mid, String name, String phone, Model model){}// 비밀번호 찾기
	 public String pwch (BoardVO bvo){
		return null;} // 비밀번호 변경 udate
	 public String pwch (MemberVO mvo){
		return null;} // 비밀번호 변경 udate

}
