package org.ArtAuc.domain;

import lombok.Data;

@Data
public class AuthVO {
	
	private String mid; // 아이디
	private String auth; // 권한

}
