package org.ArtAuc.domain;

import lombok.Data;

@Data
public class BoardAttachVO {

	private int bno;
	private String uuid;
	private String upFolder;
	private String fileName;
	
}
