package org.ArtAuc.service;

import java.util.List;

import org.ArtAuc.domain.Criteria;
import org.ArtAuc.domain.ReplyPageDTO;
import org.ArtAuc.domain.ReplyVO;

public interface ReplyService {

	
	public ReplyPageDTO list(int bno, Criteria cri); // 전체 목록 페이징
	public ReplyVO view(int rno); // rno로 하나 조회하기
	public boolean add(ReplyVO rvo); // insert 댓글 등록
	public boolean remove(int rno); // delete
	public boolean modify(ReplyVO rvo); // update
	
	public List<ReplyVO> mylist(Criteria cri); // 내 댓글 전체 목록
}
