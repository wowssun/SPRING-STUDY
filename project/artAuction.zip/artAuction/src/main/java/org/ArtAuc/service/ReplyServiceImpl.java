package org.ArtAuc.service;

import org.ArtAuc.domain.Criteria;
import org.ArtAuc.domain.ReplyPageDTO;
import org.ArtAuc.domain.ReplyVO;
import org.ArtAuc.mapper.BoardMapper;
import org.ArtAuc.mapper.ReplyMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service     												// 서비스단은 서비스 어노테이션
@Log4j
public class ReplyServiceImpl implements ReplyService {

	
	@Setter(onMethod_ = @Autowired)
	private BoardMapper boardMapper;
	
	@Setter(onMethod_ = @Autowired)
	private ReplyMapper replyMapper;
	
	
	
	public ReplyPageDTO list(int bno, Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ReplyVO view(int rno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean add(ReplyVO rvo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean remove(int rno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean modify(ReplyVO rvo) {
		// TODO Auto-generated method stub
		return false;
	}

	
}
