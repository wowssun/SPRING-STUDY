package org.ArtAuc.controller;

import org.ArtAuc.domain.Criteria;
import org.ArtAuc.domain.RequestVO;
import org.ArtAuc.service.AdminService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@AllArgsConstructor
public class AdminController {
	
	private AdminService adminService;
	
	
	 public void mypage (String mid) {} // 관리자 메뉴
	 public void userlist (Model model, Criteria cri) {} // 회원목록 list select memberVO
	 public void locklist (Model model, Criteria cri){} // 잠금회원목록 list select memberVO
	 public String unlock (RequestVO rvo, RedirectAttributes rttr){
		return null;}// 잠금해제하기 update
	 public void artuserlist (Model model, Criteria cri){} // 작가회원목록 list select memberVO
	 public void rqlist (Model model, Criteria cri){}// 작가신청목록 list select
	 public String state (RequestVO rvo, RedirectAttributes rttr,@ModelAttribute("cri") Criteria cri){
		return null;} // 작가 신청 승인 거절 update - 화면목록에 url 수정하기
	 public void checklist (Model model, Criteria cri) {}// 작가 승인 / 거절 목록 list select
	 
	 public String remove(String mid, RedirectAttributes rttr){
			return mid;} // 회원 탈퇴 remove

}
