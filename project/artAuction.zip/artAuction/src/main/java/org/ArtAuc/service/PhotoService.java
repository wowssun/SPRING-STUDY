package org.ArtAuc.service;

import org.ArtAuc.domain.PhotoVO;

public interface PhotoService {
	
	public PhotoVO view(String mid);
		public boolean add(PhotoVO pvo);
		public boolean remove(String uuid);

}
