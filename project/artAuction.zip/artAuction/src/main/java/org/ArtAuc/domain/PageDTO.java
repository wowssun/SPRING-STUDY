package org.ArtAuc.domain;

import lombok.Data;

@Data
public class PageDTO {
	
	private final double NUM_PER_PAGE = 5.0; // 한 페이지에 표시할 페이지 번호 수
	private int start; // 시작 페이지 번호
	private int end; // 끝 페이지 번호
	private boolean prev; // 이전
	private boolean next;// 다음
	private Criteria cri;// 한 페이지에 표시할 게시물의 수 및 페이지 번호
	
	
	
	
	
	
	
	public PageDTO(Criteria cri, int totalCount) {}

}
