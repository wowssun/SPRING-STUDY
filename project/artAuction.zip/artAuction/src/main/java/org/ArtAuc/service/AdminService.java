package org.ArtAuc.service;

import java.util.List;

import org.ArtAuc.domain.ArtistVO;
import org.ArtAuc.domain.Criteria;
import org.ArtAuc.domain.MemberVO;
import org.ArtAuc.domain.RequestVO;

public interface AdminService {

	
	public List<MemberVO> list(Criteria cri); //회원목록 select MemberVO
	public List<MemberVO> lockListl(Criteria cri); //잠금회원목록 select MemberVO
	public boolean lockModify(MemberVO mvo); // 잠금해제하기 update
	public List<MemberVO> artList(Criteria cri); //작가회원목록 select MemberVO
	public List<RequestVO> requeList(Criteria cri); //작가신청목록 select RequestVO
	public ArtistVO requeselect(String mid); //작가 신청상세조회 select
	public boolean requeModify(RequestVO rvo); //작가 신청 승인 / 거절 update
	public List<RequestVO> okNoList(Criteria cri); //작가 승인 / 거절 목록 select RequestVO
}
