package org.ArtAuc.service;

import java.util.List;

import org.ArtAuc.domain.BoardVO;
import org.ArtAuc.domain.Criteria;

public interface BoardService {
	
	
	public List<BoardVO> list(Criteria cri); // 전체 목록 페이징
	public BoardVO view(int bno); // bno로 하나 가져오기
	public boolean register(BoardVO bvo); // insert
	public boolean remove(int bno); // delete
	public boolean modify(BoardVO bvo); // update
	public int totalCount(Criteria cri); // 전체 게시물 수
	public void updateHit(int bno); // 게시물 조회수 증가

}
