package org.ArtAuc.domain;

import lombok.Data;

@Data
public class Criteria {
	private int amount;
	private int pageNum;// 페이지 번호
	private String type; // 검색
	private String keyword; // 검색
	
	
	
	
	
	public Criteria(int amount, int pageNum){}
	public String [] getTypeArr() {
		return null;
	}
	

}
