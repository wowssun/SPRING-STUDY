package org.ArtAuc.mapper;

import org.ArtAuc.domain.PhotoVO;

public interface PhotoMapper {
	
	public PhotoVO select(String mid);
	public int insert(PhotoVO pvo);
	public int delete(String uuid);

}
