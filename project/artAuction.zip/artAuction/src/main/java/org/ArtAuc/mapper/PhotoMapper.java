package org.ArtAuc.mapper;

import org.ArtAuc.domain.PhotoVO;

public class PhotoMapper {
	
	public PhotoVO select(String mid){
		return null;}
	public int insert(PhotoVO pvo){
		return 0;}
	public int delete(String uuid){
		return 0;}

}
