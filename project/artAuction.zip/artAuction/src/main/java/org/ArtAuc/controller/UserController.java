package org.ArtAuc.controller;

import org.ArtAuc.domain.ArtistVO;
import org.ArtAuc.domain.BoardVO;
import org.ArtAuc.domain.MemberVO;
import org.ArtAuc.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@AllArgsConstructor
public class UserController {
	
	private UserService userService;
	
	 public void mypage (String mid) {} // 마이페이지 view
	 public void myinfo (String mid ,Model model){}// 내 정보 보기 view
	 public String modify(MemberVO mvo, RedirectAttributes rttr){
		return null;}// 내 정보 수정 modify
	 public String remove(String mid, RedirectAttributes rttr){
		return mid;} // 회원 탈퇴 remove
	 public void request () {}// 작가신청 insert
	 public String request (ArtistVO avo, RedirectAttributes rttr){
		return null;}// 작가신청 insert
	 public void rqcheck (){}// 작가 신청 정보 조회
	 public void rqcheck (String mid, Model model ){}// 작가 신청 정보 조회
	 public void artview (String mid ,Model model){} // 작가 정보 보기 view
	 public String artmodify (ArtistVO avo){
		return null;}// 작가 정보 수정 modify
	 public String artmodify (ArtistVO avo, RedirectAttributes rttr){
		return null;} // 작가 정보 수정 modify

}
