package org.ArtAuc.controller;

import java.io.File;
import java.util.List;

import org.ArtAuc.domain.AttachFileDTO;
import org.ArtAuc.service.PhotoService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.multipart.MultipartFile;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@AllArgsConstructor
public class UploadController {
	
	private PhotoService photoService;
	
	public String getFolder() {
		return null;}
	public void ajaxAction(){}
	public boolean isImage(File file){
		return false;}
	public ResponseEntity<byte[]>display(String fileName){
		return null;}
	public ResponseEntity<String> deleteFile(String fileName, String type){
		return null;}
	public ResponseEntity<List<AttachFileDTO>>ajaxAction(MultipartFile[] uploadFile){
		return null;}

}
