package org.ArtAuc.mapper;

import org.ArtAuc.domain.ArtistVO;
import org.ArtAuc.domain.MemberVO;

public class UserMapper {
	
	public MemberVO select(String mid) {
		return null;} //내 정보 보기 select MemberVO
	public boolean update(MemberVO mvo){
		return false;} // 내 정보 수정 update
	public boolean delete(String mid){
		return false;} // 회원 탈퇴 delete
	public boolean insert(ArtistVO mvo){
		return false;} //작가신청 insert
	public String artSearch(String mid){
		return mid;} // 작가 신청 정보 조회 select
	public ArtistVO artSelect(String mid){
		return null;} //작가 정보 보기 select
	public boolean artUpdate(ArtistVO avo){
		return false;} // 작가 정보 수정 update

}
