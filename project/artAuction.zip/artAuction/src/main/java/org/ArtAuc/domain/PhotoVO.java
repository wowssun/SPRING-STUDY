package org.ArtAuc.domain;

import lombok.Data;

@Data
public class PhotoVO {
	
	private String mid;
	private String upFolder;
	private String fileName;

}
