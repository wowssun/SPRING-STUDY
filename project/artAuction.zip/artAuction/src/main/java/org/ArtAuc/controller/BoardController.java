package org.ArtAuc.controller;

import org.ArtAuc.domain.BoardVO;
import org.ArtAuc.domain.Criteria;
import org.ArtAuc.domain.PhotoVO;
import org.ArtAuc.service.BoardService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@AllArgsConstructor
public class BoardController {
	
	private BoardService boardService;
	
	 public String modify(BoardVO bvo, RedirectAttributes rttr,@ModelAttribute("cri") Criteria cri){
		return null;}
	 public String remove(String writer, int bno, RedirectAttributes rttr, @ModelAttribute("cri") Criteria cri){
		return writer;}
	 public void view(int bno,Model model, @ModelAttribute("cri") Criteria cri){}
	 public void list(Model model, Criteria cri){}
	 public void register(){}
	 public String register(BoardVO bvo, RedirectAttributes rttr){
		return null;}
	 public ResponseEntity <PhotoVO> photo (String mid){
		return null;}
	 
	 public void myBoardList(String mid,Model model, Criteria cri){}

}
