package org.ArtAuc.controller;

import org.ArtAuc.domain.ReplyPageDTO;
import org.ArtAuc.domain.ReplyVO;
import org.ArtAuc.service.ReplyService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@RestController    // json 받을 수 있도록 restController로 변경해야한다.
@Log4j
@RequestMapping("/replies/")
@AllArgsConstructor
public class ReplyController {
	
	private ReplyService replyService;

	
	public ResponseEntity <ReplyPageDTO> list(@PathVariable("bno") int bno,@PathVariable int pageNum){
		return null;}
	public ResponseEntity<String> add(@RequestBody ReplyVO rvo){
		return null;}
	public ResponseEntity<ReplyVO> view(@PathVariable int rno){
		return null;}
	public ResponseEntity<String> modify(@PathVariable int rno, @RequestBody ReplyVO rvo){
		return null;}
	public ResponseEntity<String> remove(@PathVariable int rno){
		return null;}
}
