package org.ArtAuc.mapper;

import org.ArtAuc.domain.MemberVO;

public interface MainMapper {
	
	public boolean insert(MemberVO mvo) ;//회원가입 insert
	public boolean idCheck(String mid); // 아이디 중복체크 
	public String midSearch(String name, String phone); //아이디찾기 select
	public String pwSearch(String mid, String name, String phone); //비밀번호찾기 select
	public boolean pwUpdate(MemberVO mvo) ;//비밀번호변경 update

}
