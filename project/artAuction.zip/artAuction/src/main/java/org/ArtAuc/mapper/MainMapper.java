package org.ArtAuc.mapper;

import org.ArtAuc.domain.MemberVO;

public class MainMapper {
	
	public boolean insert(MemberVO mvo){
		return false;} //회원가입 insert
	public String midSearch(String name, String phone){
		return phone;} //아이디찾기 select
	public String pwSearch(String mid, String name, String phone){
		return phone;} //비밀번호찾기 select
	public boolean pwUpdate(MemberVO mvo){
		return false;} //비밀번호변경 update

}
