package org.ArtAuc.service;

import org.ArtAuc.domain.PhotoVO;
import org.ArtAuc.mapper.PhotoMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service     												// 서비스단은 서비스 어노테이션
@Log4j
public class PhotoServiceImpl implements PhotoService {
	
	
	@Setter(onMethod_ = @Autowired)
	private PhotoMapper photoMapper;
	
	
	@Override
	public PhotoVO view(String mid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean add(PhotoVO pvo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean remove(String uuid) {
		// TODO Auto-generated method stub
		return false;
	}

	
}
