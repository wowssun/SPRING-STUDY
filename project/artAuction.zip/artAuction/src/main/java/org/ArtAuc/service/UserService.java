package org.ArtAuc.service;

import org.ArtAuc.domain.ArtistVO;
import org.ArtAuc.domain.MemberVO;

public interface UserService {

	
	public MemberVO view(String mid); //내 정보 보기 select MemberVO
	public boolean modify(MemberVO mvo); // 내 정보 수정 update
	public boolean remove(String mid) ;// 회원 탈퇴 delete
	public boolean register(ArtistVO mvo); //작가신청 insert
	public String artSearch(String mid); // 작가 신청 정보 조회 select
	public ArtistVO artSelect(String mid); //작가 정보 보기 select
	public boolean artModify(ArtistVO avo); // 작가 정보 수정 update
}
