package org.ArtAuc.service;

import java.util.List;

import org.ArtAuc.domain.BoardVO;
import org.ArtAuc.domain.Criteria;
import org.ArtAuc.mapper.BoardMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service     												// 서비스단은 서비스 어노테이션
@Log4j
public class BoardServiceImpl implements BoardService {
	
	@Setter(onMethod_ = @Autowired)
	private BoardMapper boardMapper;
	
	
	@Override
	public List<BoardVO> list(Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BoardVO view(int bno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean register(BoardVO bvo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean remove(int bno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean modify(BoardVO bvo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int totalCount(Criteria cri) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void updateHit(int bno) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<BoardVO> mylist(Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}



}
