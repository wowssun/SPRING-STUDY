package org.ArtAuc.service;

import java.util.List;

import org.ArtAuc.domain.ArtistVO;
import org.ArtAuc.domain.Criteria;
import org.ArtAuc.domain.MemberVO;
import org.ArtAuc.domain.RequestVO;
import org.ArtAuc.mapper.AdminMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service     												// 서비스단은 서비스 어노테이션
@Log4j
public class AdminServiceImpl implements AdminService {
	
	@Setter(onMethod_ = @Autowired)
	private AdminMapper adminMapper;
	
	
	
	@Override
	public List<MemberVO> list(Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<MemberVO> lockListl(Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean lockModify(MemberVO mvo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<MemberVO> artList(Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RequestVO> requeList(Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArtistVO requeselect(String mid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean requeModify(RequestVO rvo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<RequestVO> okNoList(Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
}
