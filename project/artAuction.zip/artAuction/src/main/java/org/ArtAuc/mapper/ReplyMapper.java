package org.ArtAuc.mapper;

import java.util.List;

import org.ArtAuc.domain.Criteria;
import org.ArtAuc.domain.ReplyVO;
import org.apache.ibatis.annotations.Param;

public interface ReplyMapper {
	
	public List<ReplyVO> reSelectAllPaging(@Param("bno") int bno,@Param("cri") Criteria cri); // 전체 목록 페이징
	public int reInsert(ReplyVO rvo);// insert
	public ReplyVO reSelect(int rno); // rno로 하나 가져오기
	public int reDelete(int rno) ;// delete
	public int reUpdate(ReplyVO rvo); // update
	public int reDeleteAll(int bno); // 댓글 전체 삭제
	
	public List<ReplyVO> mylist(Criteria cri); // 내 댓글 전체 목록

}
