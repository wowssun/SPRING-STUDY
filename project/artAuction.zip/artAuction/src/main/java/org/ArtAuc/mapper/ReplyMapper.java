package org.ArtAuc.mapper;

import java.util.List;

import org.ArtAuc.domain.Criteria;
import org.ArtAuc.domain.ReplyVO;
import org.apache.ibatis.annotations.Param;

public class ReplyMapper {
	
	public List<ReplyVO> reSelectAllPaging(@Param("bno") int bno,@Param("cri") Criteria cri){
		return null;} // 전체 목록 페이징
	public int reInsert(ReplyVO rvo){
		return 0;} // insert
	public ReplyVO reSelect(int rno){
		return null;} // rno로 하나 가져오기
	public int reDelete(int rno){
		return rno;} // delete
	public int reUpdate(ReplyVO rvo){
		return 0;} // update
	public int reDeleteAll(int bno){
		return bno;} // 댓글 전체 삭제

}
