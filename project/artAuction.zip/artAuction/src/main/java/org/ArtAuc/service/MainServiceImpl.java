package org.ArtAuc.service;

import org.ArtAuc.domain.MemberVO;
import org.ArtAuc.mapper.MainMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service     												// 서비스단은 서비스 어노테이션
@Log4j
public class MainServiceImpl implements MainService {
	
	@Setter(onMethod_ = @Autowired)
	private MainMapper mainMapper;
	
	
	@Override
	public boolean register(MemberVO mvo) {
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public boolean idCheck(String mid) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String midSearch(String name, String phone) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String pwSearch(String mid, String name, String phone) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean pwModify(MemberVO mvo) {
		// TODO Auto-generated method stub
		return false;
	}


	
}
