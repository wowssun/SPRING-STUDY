package org.ArtAuc.mapper;

import java.util.List;

import org.ArtAuc.domain.BoardVO;
import org.ArtAuc.domain.Criteria;
import org.apache.ibatis.annotations.Param;

public interface BoardMapper {

	
	public List<BoardVO> list(Criteria cri); // 전체 목록 페이징
	public BoardVO view(int bno); // bno로 상세조회
	public boolean register(BoardVO bvo); // insert
	public boolean remove(int bno); // delete
	public boolean modify(BoardVO bvo); // update
	public int totalCount(Criteria cri);// 전체 게시물 수
	public void updateHit(int bno); // 게시물 조회수 증가
	
	// 댓글 수 업데이트
	public int updateReplyCnt(@Param("amount") int amount, @Param("bno") int bno);
}
