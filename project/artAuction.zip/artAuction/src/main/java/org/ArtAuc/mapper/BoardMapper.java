package org.ArtAuc.mapper;

import java.util.List;

import org.ArtAuc.domain.BoardVO;
import org.ArtAuc.domain.Criteria;
import org.apache.ibatis.annotations.Param;

public class BoardMapper {
	
	public List<BoardVO> list(Criteria cri){
		return null;} // 전체 목록 페이징
	public BoardVO view(int bno){
		return null;} // bno로 상세조회
	public boolean register(BoardVO bvo){
		return false;} // insert
	public boolean remove(int bno){
		return false;} // delete
	public boolean modify(BoardVO bvo){
		return false;} // update
	public int totalCount(Criteria cri){
		return 0;}  // 전체 게시물 수
	public void updateHit(int bno){} // 게시물 조회수 증가
	
	// 댓글 수 업데이트
	public int updateReplyCnt(@Param("amount") int amount, @Param("bno") int bno) {
		return 0;
	}

}
