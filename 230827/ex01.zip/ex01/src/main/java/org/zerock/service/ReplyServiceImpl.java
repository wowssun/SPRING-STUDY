package org.zerock.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.zerock.domain.Criteria;
import org.zerock.domain.ReplyPageDTO;
import org.zerock.domain.ReplyVO;
import org.zerock.mapper.ReplyMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;


// @AllArgsConstructor 나 @Setter 붙이기!

@Service     												// 서비스단은 서비스 어노테이션
@AllArgsConstructor											// 생성자
@Log4j
public class ReplyServiceImpl implements ReplyService {

	private ReplyMapper replyMapper;	
	
	@Override
	public ReplyVO view(int rno) {
		
		log.info("reply view....");
		return replyMapper.reSelect(rno);
	}

	@Override
	public boolean add(ReplyVO rvo) {
		
		return replyMapper.reInsert(rvo)==1;
	}

	@Override
	public boolean remove(int rno) {
		log.info("reply remove....");
		return replyMapper.reDelete(rno)==1;
	}

	@Override
	public boolean modify(ReplyVO rvo) {
		log.info("reply modify....");
		return replyMapper.reUpdate(rvo) ==1;
	}

	@Override
	public ReplyPageDTO list(int bno, Criteria cri) {
		
		// pto에 생성자를 만들었으니 dto에 두개를 담아서 보내면 된다.
		return new ReplyPageDTO(replyMapper.selectReply(bno),replyMapper.reSelectAllPaging(bno,cri));
	}



}
