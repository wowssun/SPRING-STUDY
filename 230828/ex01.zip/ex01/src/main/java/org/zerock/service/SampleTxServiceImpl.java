package org.zerock.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.zerock.mapper.SampleMapper1;
import org.zerock.mapper.SampleMapper2;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Service   												// 서비스단은 서비스 어노테이션
@AllArgsConstructor											// 생성자
@Log4j
public class SampleTxServiceImpl implements SampleTxService {
	
	public SampleMapper1 sampleMapper1;
	public SampleMapper2 sampleMapper2;

	@Transactional
	@Override
	public void txTest(String data) {
		
		sampleMapper1.insertCol(data);
		sampleMapper2.insertCol(data);
	
		// 동일한 데이터(11 ~ 100) 를 두 테이블에 삽입
		
	}

}
