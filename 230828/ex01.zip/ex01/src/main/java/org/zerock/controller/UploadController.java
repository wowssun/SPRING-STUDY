package org.zerock.controller;

import java.io.File;
import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/upload/*")
public class UploadController {
		
		
				@GetMapping("ajaxAction")
				public void ajaxAction(){
					log.info("ajaxAction()................." );
						
					 
				}
				
				// 폼에서 받아와서 처리하는건 이거고 배열로 받기 . 이제 폼을 전송하는건 post로 처리
				@PostMapping("ajaxAction")
				public void ajaxAction(MultipartFile[] uploadFile) {	// 여기 받는 이름이랑 formtag에  input name이랑 같게한다.
					log.info("ajaxAction upload.....");
					String upPath = "c:\\upload";   // 폴더 경로
					for(MultipartFile multi : uploadFile) {
						log.info("name : " + multi.getOriginalFilename());
						log.info("size : " + multi.getSize());
						log.info("----------------");
						
						File saveFile = new File(upPath, multi.getOriginalFilename());  // 위에 선언해놓은 경로로 파일 save
						
						try {
							multi.transferTo(saveFile);   // 파일 업로드 처리
						}catch(IllegalStateException e) {
							e.printStackTrace();
						}catch(IOException e) {
							e.printStackTrace();
						}
					}
				}
	
		 
		// 화면에 뿌리는건 getMapping으로 한다. 그냥 화면 들어온것도 마찬가지(화면표시)
			@GetMapping("formAction")
			public void formAction(){
				log.info("formAction()................." );
					
				 
			}
	
			
		// 폼에서 받아와서 처리하는건 이거고 배열로 받기 . 이제 폼을 전송하는건 post로 처리
			@PostMapping("formAction")
			public void Action(MultipartFile[] uploadFile) {	// 여기 받는 이름이랑 formtag에  input name이랑 같게한다.
				log.info("Action.....");
				String upPath = "c:\\upload";   // 폴더 경로
				for(MultipartFile multi : uploadFile) {
					log.info("name : " + multi.getOriginalFilename());
					log.info("size : " + multi.getSize());
					log.info("----------------");
					
					File saveFile = new File(upPath, multi.getOriginalFilename());  // 위에 선언해놓은 경로로 파일 save
					
					try {
						multi.transferTo(saveFile);   // 파일 업로드 처리
					}catch(IllegalStateException e) {
						e.printStackTrace();
					}catch(IOException e) {
						e.printStackTrace();
					}
				}
}
}	