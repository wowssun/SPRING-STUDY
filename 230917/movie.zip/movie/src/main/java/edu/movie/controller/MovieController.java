package edu.movie.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import edu.movie.domain.MovieVO;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/movie/")
public class MovieController {
	
	// 지정된 url의 html 가져오기
	
	@GetMapping("chart") // movie/chart get 매핑
	public List<MovieVO> cart(Model model){		// Movie List로 반환하는 chart()
		
		 List<MovieVO> movieList = new ArrayList<MovieVO>();
		 
		 String  cgv = "http://www.cgv.co.kr/movies/?lt=1&ft=0";
		 try {
			Document doc = Jsoup.connect(cgv).get();			// jsoup으로 Document import 하기
			// log.info(doc);
			Elements charDiv = doc.select("div.sect-movie-chart");    // jsoup으로 Elements import 하기  div의 클래스 ckwdkdhrl
			Elements chartOL = charDiv.eq(0).select("ol");
			
			// log.info(chartOL.size());     // 여기서는 ol이 3개 나옴
			
			for(int i = 0; i<chartOL.size(); i++ ) {
				Elements charLI = chartOL.eq(i).select("li");
					// log.info(charLI.size());    // ol안에 있는 각각의 li 개수
				for(int j = 0; j < charLI.size(); j++) {
					String title = charLI.eq(j).select("strong.title").text();		
					String img = charLI.eq(j).select("div.box-image img").attr("src");
					String percent = charLI.eq(j).select("strong.percent").text();
					String openDate = charLI.eq(j).select("span.txt-info").text();
					
					log.info(title + img + percent + openDate.split(" ")[0]);
					
					// movieVO에 담기
					MovieVO mvo = new MovieVO();
					mvo.setTitle(title);
					mvo.setImg(img);
					mvo.setPercent(percent);
					mvo.setOpenDate(openDate);
						
					movieList.add(mvo);
							
				} // for end
					
			}  // for end
						
		} catch (IOException e) {
			e.printStackTrace();
		}   
		 model.addAttribute("movieList", movieList);
		return movieList;
	}   // cart end
			
	
}
